import React from "react";

const colunas = [
  {
    dataField: "Nome do Relatório",
    text: "Nome do Relatório",
    sort: true,
    formatter: (cell) => {
      return (
        <>
          <div style={{ fontSize: "10px", maxWidth: "200px", whiteSpace: 'normal', lineHeight: "1.4" }}>{cell}</div>
        </>
      );
    },
    headerStyle: () => {
      return {
        maxWidth: "200px",
        minWidth: "200px",
        padding: "5px",
        textAlign: "center",
        fontSize: "12px",
      };
    },
  },
  {
    dataField: "Macrocritério",
    text: "Macrocritério",
    sort: true,
    formatter: (cell) => {
      return (
        <>
          <div style={{ fontSize: "10px", widthMax: "200px", lineHeight: "normal" }}>{cell}</div>
        </>
      );
    },
    headerStyle: () => {
      return {
        widthMax: "200px",
        padding: "5px",
        textAlign: "center",
        fontSize: "12px",
      };
    },
  },
  {
    dataField: "Critério",
    text: "Critério",
    sort: true,
    formatter: (cell) => {
      return (
        <>
          <div style={{ fontSize: "10px", maxWidth: "200px", whiteSpace: 'normal', lineHeight: "1.4" }}>{cell}</div>
        </>
      );
    },
    headerStyle: () => {
      return {
        maxWidth: "200px",
        minWidth: "200px",
        padding: "5px",
        textAlign: "center",
        fontSize: "12px",
      };
    },
  },
  {
    dataField: "Subcritério",
    text: "Subcritério",
    sort: true,
    formatter: (cell) => {
      return (
        <>
          <div style={{ fontSize: "10px", maxWidth: "200px", whiteSpace: 'normal', lineHeight: "1.4" }}>{cell}</div>
        </>
      );
    },
    headerStyle: () => {
      return {
        maxWidth: "200px",
        minWidth: "200px",
        padding: "5px",
        textAlign: "center",
        fontSize: "12px",
      };
    },
  },
  {
    dataField: "Mês",
    text: "Mês",
    sort: true,
    formatter: (cell) => {
      return (
        <>
          <div style={{ fontSize: "10px", width: "100%", lineHeight: "normal" }}>{cell}</div>
        </>
      );
    },
    headerStyle: () => {
      return {
        padding: "5px",
        textAlign: "center",
        fontSize: "12px",
      };
    },
  },
  {
    dataField: "Questionário",
    text: "Questionário",
    sort: true,
    formatter: (cell) => {
      return (
        <>
          <div style={{
            fontSize: "10px", maxWidth: "300px", whiteSpace: 'normal', lineHeight: "1.4"
          }}>{cell}</div>
        </>
      );
    },
    headerStyle: () => {
      return {
        maxWidth: "300px",
        minWidth: "300px",
        padding: "5px",
        textAlign: "center",
        fontSize: "12px",
      };
    },
  },
  {
    dataField: "Resposta",
    text: "Resposta",
    sort: true,
    formatter: (cell) => {
      return (
        <>
          <div style={{ fontSize: "10px", maxWidth: "150px", whiteSpace: 'normal', lineHeight: "1.4" }}>{cell}</div>
        </>
      );
    },
    headerStyle: () => {
      return {
        maxWidth: "150px",
        minWidth: "150px",
        padding: "5px",
        textAlign: "center",
        fontSize: "12px",
      };
    },
  }
];

export default colunas;
