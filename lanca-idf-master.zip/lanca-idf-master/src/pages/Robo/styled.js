import styled from 'styled-components';


export const ContentWrapper = styled.div`
  display: flex;
  flex-direction: column;
  padding: 20px 20px;
`

export const WrapperButton = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
`
export const DadosRelatorioWrapper = styled.div`
  display: flex;
  flex-direction: column;
  margin: 20px 0px;
  justify-content: flex-start;
`


export const LogWrapper = styled.div`
  display: flex;
  flex-direction: column;
  margin: 20px 0px;
  justify-content: flex-start;
`

export const OrientacaoWrapper = styled.div`
  display: flex;
  flex-direction: column;
  margin: 20px 0px;
  justify-content: flex-start;
  line-height: 1.2;
`

export const OrientacaoAlert = styled.div`
  display: flex;
  flex-direction: row;
  margin-right: 10px;
  justify-content: flex-start;
`

export const OrientacaoText = styled.div`
  margin-left: 10px;
  margin-top: 5px;
`

export const ProgressWrapper = styled.div`
  display: flex;
  flex-direction: column;
  margin: 5px 0px;
  justify-content: flex-start;
  line-height: 1.2;
`

export const ProgressTitle = styled.div``
export const ProgressBarWrapper = styled.div`
  margin: 5px 0px;
  border: 1px solid #006298;
  width: 100%;
  height: 30px;
`
export const ProgressBar = styled.div`
  display: flex;
  width: ${props => (props.size) + "%"}; 
  height: 100%;
  background: #006298;
  align-items: center;
  justify-content: center;
`

export const WrapperMoreInfo = styled.div`
  display: flex;
  flex-direction: row;
  margin: 5px 0px;
  justify-content: space-between;
  line-height: 1.2;
`

export const ProgressBarMoreInfo = styled.div``
export const ProgressBarDetailStatus = styled.a`
  cursor: pointer;
  color: blue !important;
  &:hover{
    text-decoration: underline !important;
  }
`
export const WrapperTable = styled.div`
  display: ${props => (props.visible ? "flex" : "none")}; 
  flex-direction: column;
`

export const ProgressValue = styled.div`
display: flex;
  margin: auto;
  color: white;
`