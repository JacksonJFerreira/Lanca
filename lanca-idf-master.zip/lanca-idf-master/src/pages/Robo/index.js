import React, { useState, useEffect } from "react";
import Log from "../../components/RoboComponents/Log";
import Layout from "../../components/Layout";
import Line from "../../components/Line";
import Title from "../../components/Title";
import {
  Container,
  Col,
  Form,
  Alert,
  Row,
  Button,
  Spinner,
  Badge,
  ButtonGroup,
  ToggleButton
} from "react-bootstrap";
import "./styles.css";
import ToolkitProvider, {
  Search
} from "react-bootstrap-table2-toolkit/dist/react-bootstrap-table2-toolkit";
import BootstrapTable from "react-bootstrap-table-next";
import paginationFactory from "react-bootstrap-table2-paginator";

import colunas from "./configuracaoTable";
import colunasPregressDetail from "./statusParametroTable";

import * as S from "./styled";

import ipc from "../../services/icp";


const RoboPage = () => {
  const { SearchBar } = Search;
  // trecho de código usado quando o Lança IDF rodava usando o front end do Portal SSUB
  // const isSoftware = (navigator.userAgent.toLowerCase().indexOf(' electron/') > -1 ?
  //   true : false);
  const isSoftware = true;

  const [buttonDisabled, setButtonDisabled] = useState(false);
  const [idf, setIdf] = useState({
    enderecoRede: '',
    parametroPesquisa: '1'
  });
  const [isMoreInfo, setIsMoreInfo] = useState(false);
  const [isLoading, setIsLoading] = useState({
    lendo: false,
    trabalhandoFiscal: false,
    trabalhandoGerente: false,
  });
  const radios = [
    { name: 'Contrato', value: '1' },
    { name: 'FRS', value: '2' },
  ];
  const [parametros, setParametros] = useState([]);
  const [data, setData] = useState([]);
  const [progressDone, setProgressDone] = useState(0);
  const [progress, setProgress] = useState(0);
  const [logInfo, setLogInfo] = useState([]);
  const [logError, setLogError] = useState([]);
  const [responseLog, setResponseLog] = useState('');
  const [responseError, setResponseError] = useState('');
  const [resposta, setResposta] = useState({
    mensagem: "",
    feedback: "",
    show: false,
  });

  React.useEffect(() => {
    setLogInfo([...logInfo, responseLog]);
  }, [responseLog]);

  React.useEffect(() => {
    setLogError([...logError, responseError]);
  }, [responseError]);

  useEffect(() => {
    parametroFormatter();
  }, [data]);

  useEffect(async () => {
    if (ipc != null) {
      await ipc.send("runShowVersao");

      return function cleanup() {
        ipc.removeAllListeners('responseVersao');
      };
    }
  }, []);

  function parametroFormatter() {
    let aux = 0;
    let relatorio = [];
    console.log(data);
    while (aux < data.length && data.length > 0) {
      console.log("aux");
      console.log(aux);
      relatorio.push({ "parametro": data[aux]["Nome do Relatório"], "status": "Não Realizado" });
      console.log(data[aux]["Nome do Relatório"]);
      console.log(data[aux]["Quantidade Questões"]);
      aux = aux + data[aux]["Quantidade Questões"];
    }

    setParametros(relatorio);
  }

  async function RPA(ator) {
    if (data.length == 0) {
      setResposta({
        mensagem: "Antes de iniciar o script deve ser carregado os dados clicando no botão Ler Planilhas!",
        feedback: "erro",
        show: true,
      });
      return;
    }
    setIsLoading((ator == "fiscal" ? { trabalhandoFiscal: true } : { trabalhandoGerente: true }));
    setButtonDisabled(true);

    if (ator == "fiscal") {
      await ipc.send("runScriptIDFFiscal", idf, data, parametros);
    } else {
      await ipc.send("runScriptIDFGerente", idf, data, parametros);
    }

    ipc.on('responseRunIDFLog', (event, result) => {
      setResponseLog(result);
    });

    ipc.on('responseRunIDFErro', (event, result) => {
      setResponseError(result);
    });

    ipc.on('responseStatusObjeto', (event, result) => {
      setParametros(result);
    });

    ipc.on('responseError', (event, result) => {
      console.log("ERROR!")
      setResposta({
        mensagem:
          " Ocorreu algum erro no script. Click em Detalhe, abaixo da barra de progresso para identificar qual ou quais foram os relatório que resultaram em erro.",
        feedback: "info",
        show: true
      });
    });


    ipc.on('responseProgressoBar', (event, result) => {
      setProgress(result);
      let temErro = false;
      parametros.map((param) => {
        if (param.status == "Erro ao rodar script") {
          temErro = true;
        }
      })
      if (temErro) {
        setResposta({
          mensagem:
            " Script em andamento, porém tem algum processo que não foi processado. Click em Detalhe, abaixo da barra de progresso para identificar qual ou quais foram os relatório que resultaram em erro.",
          feedback: "info",
          show: true
        });
      }
    });

    ipc.on('responseProgressDone', (event, result) => {
      setProgressDone(result);
    });

    ipc.on('responseRunIDF', (event, result) => {
      let qtdErros = 0;
      parametros.map((param) => {
        console.log("param.status: " + param.status);
        if (param.status == "Erro ao rodar script") {
          qtdErros = qtdErros + 1;
          console.log("qtdErros: " + qtdErros);
        }
      })

      if (result.feedback == "erro") {
        setResposta({
          mensagem: result.mensagem,
          feedback: result.feedback,
          show: result.show
        });
      } else {
        if (qtdErros == parametros.length) {
          setResposta({
            mensagem: "Todos os contratos tiveram erro na execução! Consulte o Log de Erros para analisar o problema.",
            feedback: "error",
            show: true
          });
        } else {
          setResposta({
            mensagem: qtdErros > 0 ? result.mensagem +
              " Alguns contratos tiveram erro na execução, consulte o Log de Erros para analisar o problema."
              : "Execução do script realiazado com sucesso!",
            feedback: qtdErros > 0 ? "error" : "sucesso",
            show: true
          });
        }
      }
      setButtonDisabled(false);
      setIsLoading((ator == "fiscal" ? { trabalhandoFiscal: false } : { trabalhandoGerente: false }));
    });

    // Cleanup the listener events so that memory leaks are avoided.
    return function cleanup() {
      ipc.removeAllListeners('responseRunIDF');
      ipc.removeAllListeners('responseRunIDFLog');
    };
  }

  async function loadDados() {
    setProgress(0);
    if (idf.enderecoRede == '') {
      setResposta({
        mensagem: "Para realizar essa ação o campo de Endereço de Rede deve estar preenchido!",
        feedback: "erro",
        show: true,
      });
      return;
    }
    setButtonDisabled(true);
    setIsLoading({ lendo: true });

    await ipc.send("readIDF", idf);

    ipc.on('responseRunIDFLog', (event, result) => {
      setResponseLog(result);
    });

    ipc.on('responseRunIDFErro', (event, result) => {
      setResponseError(result);
    });

    ipc.on('responseReadIDF', (event, result) => {
      if (result.feedback == "erro") {
        setResposta({
          mensagem: result.mensagem,
          feedback: result.feedback,
          show: result.show
        });
      } else {
        setResposta({
          mensagem: "Planilha(s) carregada(s) com sucesso!",
          feedback: "sucesso",
          show: true
        });
        console.log("result");
        console.log(result);
        setData(result);
      }
      setButtonDisabled(false);
      setIsLoading({ lendo: false });
    });

    // Cleanup the listener events so that memory leaks are avoided.
    return function cleanup() {
      ipc.removeAllListeners('responseRunIDF');
      ipc.removeAllListeners('responseRunIDFLog');
    };
  }

  return (
    <>
      <Layout>
        <Container className="container-idf">
          <Title
            corFonte="azul"
            corDetalhe="amarelo"
            texto="Lança IDF"
          />
          <Line />
          <Alert
            style={{ whiteSpace: "pre-wrap" }}
            show={resposta.show}
            variant={resposta.feedback == "sucesso" ? "success" : "danger"}
          >
            {resposta.mensagem}
          </Alert>


          <Row>
            <Col md="6">
              <Form.Row>
                <Form.Group as={Col} md="7" controlId="idf_endereco_rede">
                  <Form.Label>Endereço de Rede</Form.Label>
                  <Form.Control
                    disabled={!isSoftware}
                    type="text"
                    required
                    value={idf.enderecoRede}
                    onChange={(event) =>
                      setIdf({ ...idf, enderecoRede: event.target.value })
                    }
                  />
                </Form.Group>
              </Form.Row>
              <Form.Row>
                <Form.Group as={Col} md="5" controlId="idf_parametro" id="grp_idf_parametro">
                  <Form.Label>Parâmetro de Pesquisa</Form.Label>
                  <ButtonGroup>
                    {radios.map((radio, idx) => (
                      <ToggleButton
                        key={idx}
                        id={`radio-${idx}`}
                        type="radio"
                        variant="outline-primary"
                        name="radio"
                        value={radio.value}
                        checked={idf.parametroPesquisa === radio.value}
                        onChange={(event) =>
                          setIdf({ ...idf, parametroPesquisa: event.target.value })
                        }
                      >
                        &nbsp;&nbsp;{radio.name}
                      </ToggleButton>
                    ))}
                  </ButtonGroup>
                </Form.Group>
              </Form.Row>
            </Col>


            <Col>
              {isSoftware ? "" :
                <>
                  <S.OrientacaoWrapper>
                    <S.OrientacaoAlert>
                      <div>
                        <Badge className="span-badge" style={{ height: "40px", width: "40px", fontSize: "24px" }} variant="danger">!</Badge>
                      </div>
                    </S.OrientacaoAlert>
                  </S.OrientacaoWrapper>

                </>
              }
              {isSoftware ?
                <S.ProgressWrapper>
                  <S.ProgressTitle>Progresso do Script</S.ProgressTitle>
                  <S.ProgressBarWrapper>
                    <S.ProgressBar size={progress.toFixed(2)}>
                      <S.ProgressValue>{`${progress.toFixed(2)} %`}</S.ProgressValue>
                    </S.ProgressBar>
                  </S.ProgressBarWrapper>
                  <S.WrapperMoreInfo>
                    <S.ProgressBarMoreInfo>{`${progressDone} / ${parametros.length} Planilhas Lançadas`}</S.ProgressBarMoreInfo>
                    <S.ProgressBarDetailStatus onClick={() => setIsMoreInfo(!isMoreInfo)}> {isMoreInfo ? " - " : " + "} Detalhes</S.ProgressBarDetailStatus>
                  </S.WrapperMoreInfo>
                  <S.WrapperTable id="wrapper_table_status" visible={isMoreInfo}>
                    <Line />
                    <ToolkitProvider
                      id="table_status_contrato"
                      keyField="id"
                      data={parametros}
                      columns={colunasPregressDetail}
                      size={200}
                    >
                      {(props) => (
                        <>
                          <BootstrapTable
                            {...props.baseProps}

                            classes="table_status_contrato"
                            noDataIndication="Nenhum Registro encontrado"
                          />
                        </>
                      )}
                    </ToolkitProvider>
                  </S.WrapperTable>
                </S.ProgressWrapper>


                : ''
              }
            </Col>
          </Row>

          <S.WrapperButton>
            <Row>
              <Col>
                <Button
                  className="btn-warning"
                  onClick={loadDados}
                  disabled={buttonDisabled || !isSoftware}
                >{isLoading.lendo ?
                  <Spinner
                    as="span"
                    size="sm"
                    animation="border"
                    role="status"
                    aria-hidden="true"
                  />
                  : " "}{" Ler Planilhas"}
                </Button>
                <div className="pipe">{" | "}</div>
                <Button
                  onClick={() => RPA("fiscal")}

                  className="btn-success"
                  disabled={buttonDisabled || !isSoftware}
                >{isLoading.trabalhandoFiscal ?
                  <Spinner
                    as="span"
                    size="sm"
                    animation="border"
                    role="status"
                    aria-hidden="true"
                  />
                  : " "}
                  {"Script do Fiscal Contrato"}
                </Button>{" "}
                <Button
                  onClick={() => RPA("gerente")}
                  disabled={buttonDisabled || !isSoftware}
                >{isLoading.trabalhandoGerente ?
                  <Spinner
                    as="span"
                    size="sm"
                    animation="border"
                    role="status"
                    aria-hidden="true"
                  />
                  : " "}
                  {"Script do Gerente Contrato"}
                </Button>
                <div className="pipe">{" | "}</div>
                <Button
                  className="btn-info"
                  href="#log-acao"
                  disabled={buttonDisabled || !isSoftware}
                >Visualizar Log
                </Button>
              </Col>

            </Row>
          </S.WrapperButton>

          <S.DadosRelatorioWrapper>
            <Title
              corFonte="azul"
              corDetalhe="amarelo"
              texto="Dados Carregados"
            />
            <Line />
            <ToolkitProvider
              keyField="id"
              data={data}
              columns={colunas}
              search
            >
              {(props) => (
                <>
                  <Row>
                    <Col sm="3">
                      <SearchBar
                        {...props.searchProps}
                        placeholder={"Pesquisar"}
                      />
                    </Col>
                    <Col>
                      <div style={{ fontSize: "12px" }}>Total de Planilhas Carregadas:{" " + (parametros.length)}</div>
                      <div style={{ fontSize: "12px" }}>Total de Colunas:{" " + colunas.length}</div>
                    </Col>
                    <Col>
                    </Col>
                  </Row>
                  <BootstrapTable
                    {...props.baseProps}
                    id="table_carga"
                    classes="table_idf"
                    pagination={paginationFactory({
                      sizePerPage: 26
                    })}
                    noDataIndication="Nenhum Registro encontrado"
                  />
                </>
              )}
            </ToolkitProvider>
          </S.DadosRelatorioWrapper>
          <S.LogWrapper id="log-acao">
            <Title
              corFonte="azul"
              corDetalhe="amarelo"
              texto="Log de Ações"
            />
            <Log contents={logInfo} />
          </S.LogWrapper>
          <S.LogWrapper id="log-erro">
            <Title
              corFonte="azul"
              corDetalhe="amarelo"
              texto="Log de Erros"
            />
            <Log contents={logError} />
          </S.LogWrapper>
        </Container>
      </Layout>
    </>
  );
};

export default RoboPage;
