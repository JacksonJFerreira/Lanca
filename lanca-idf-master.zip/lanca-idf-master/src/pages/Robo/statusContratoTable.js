import React from "react";

const colunas = [
  {
    dataField: "contrato",
    text: "Contrato",
    formatter: (cell) => {
      return (
        <>
          <div style={{ fontSize: "10px", whiteSpace: 'normal', lineHeight: "1.4" }}>{cell}</div>
        </>
      );
    },
    headerStyle: () => {
      return {
        padding: "5px",
        textAlign: "center",
        fontSize: "12px",
      };
    },
  },
  {
    dataField: "status",
    text: "Status",
    formatter: (cell) => {
      return (
        <>
          <div style={{ fontSize: "10px", lineHeight: "normal" }}>{cell}</div>
        </>
      );
    },
    headerStyle: () => {
      return {
        padding: "5px",
        textAlign: "center",
        fontSize: "12px",
      };
    },
  },
];

export default colunas;
