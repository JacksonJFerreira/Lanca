import React from "react";
import { HashRouter, Switch, Route } from "react-router-dom";

import RoboPage from "./pages/Robo";
import LoadScreen from "./components/RoboComponents/LoadScreen";


const Routes = () => {

  return (
    <>
      < HashRouter >
        <Switch>
          <Route path="/loading" exact component={LoadScreen} />
          <Route path="/" exact component={RoboPage} />
        </Switch>
      </HashRouter >
    </>
  );
};

export default Routes;
