const { Builder, By, until, Key, WebDriver, Capabilities, Capability } = require("selenium-webdriver");
const { Condition } = require('selenium-webdriver/lib/webdriver');
const moment = require('moment');
//TODO: Retirar isso, assim que terminar os testes com o Contrato: 4600661244
const isDev = require("electron-is-dev");
//const isDev = !require("electron-is-dev");

class RPA {
  constructor(event, browser = "firefox") {
    this.event = event;
    this.browser = browser;
  }

  async initProcess() {
    this.event.sender.send('responseRunIDFLog', moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - " + "Inicializando Script...");
    //Link de produção
    let url_prod = "https://erpweb.petrobras.com.br/sap/bc/webdynpro/sap/yswd_comp_graph_21_ajustada?CLASSE=YSMM_CL_PGBF_MONITOR_REL&sap-client=400&sap-language=PT#";


    let driver = await new Builder()
      .forBrowser(this.browser)
      .build();
    await driver.get(
      url_prod
    );


    // var start_1 = Date.now();

    // //let hasPageAlert = await this.waitLocatedById(driver, 'advancedButton', start, "Stela de Alerta de potencial de risco");
    // //console.log(hasPageAlert);
    // if (await this.waitLocatedById(this.event, driver, 'advancedButton', start_1, "Aguardar Tela de Alerta")) {
    //   await driver.sleep(1000);
    //   await this.clickById(this.event, driver, 'advancedButton', start_1, "Click no Botão Avançado");
    //   await driver.sleep(1000);
    //   await this.clickById(this.event, driver, 'exceptionDialogButton', start_1, "Click no Botão Continuar");
    //   await driver.sleep(1000);
    //   await driver.switchTo().alert().accept();
    // }

    // // Realizar login (deverá ser realizada alteração para se adaptar no ambiente de produção);
    // await driver
    //   .wait(
    //     until.elementLocated(By.xpath("//*[text()='Usuário']"), 30000)
    //   ).then(async function () {
    //     await driver.sleep(2000);
    //   })
    // // procurar por campo de usuário e senha do SAP NetWeaver

    var start = Date.now();
    if (isDev) {
      this.event.sender.send('responseRunIDFLog', "1# Modo Devesenvolvimento");
    } else {
      this.event.sender.send('responseRunIDFLog', "1# Modo Produção");
    }

    // // Autenticar no SAP
    // await this.sendKeyByClassName(this.event, driver, chave, "lsField__input", 2, start, "Inserir Chave");
    // await this.sendKeyByClassName(this.event, driver, senha, "lsField__input", 3, start, "Inserir Senha");
    // await this.clickById(this.event, driver, 'LOGON_BUTTON', start, "Click no Botão Logon SAP");

    // if (await this.waitLocatedById(this.event, driver, 'SESSION_QUERY_CONTINUE_BUTTON', start_1, "Aguardar Botão de Sessão")) {
    //   await this.clickById(this.event, driver, 'SESSION_QUERY_CONTINUE_BUTTON', start_1, "Click no Botão Logon SAP Avançar");
    // }

    // if (await this.waitLocatedById(this.event, driver, 'SYSTEM_MESSAGE_CONTINUE_BUTTON', start_1, "Aguardar Botão de Avançar de Mesangem de Sistema do SAP")) {
    //   await this.clickById(this.event, driver, 'SYSTEM_MESSAGE_CONTINUE_BUTTON', start_1, "Click no Botão de Avançar de Mesangem de Sistema do SAP");
    // }

    await this.waitLocatedByText(this.event, driver, 'Avaliação Periódica de Contratos de Serviços', 60000, start, "Aguardar Avaliação Periódica de Contratos de Serviços");
    // verificação se a página de Menu está carregada;

    //await this.clickByClassName(driver, "lsLink", 3, start, "press 4th item menu");
    await this.clickByText(this.event, driver, "Avaliação Periódica de Contratos de Serviços", 0, start, "Click no Botão Avaliação Periódica de Contratos de Serviços");

    return driver;
  }

  async script(driver, dados, index, parametroPesquisa, ator) {
    // Verificar se a página de pesquisa está carregada

    var start = Date.now();

    await this.waitLocatedByText(this.event, driver, 'Parâmetros de Pesquisa', 60000, start, 'Aguardar Tela de Parâmetros de Pesquisa');
    var fieldInput = 0;

    // field input = 4 - Se for Contrato
    // field input = 6 - Se for FTS
    if (parametroPesquisa == 1) {
      fieldInput = 4;
    } else {
      fieldInput = 6;
    }

    // na primeira vez que acessar a página de pesquisa e clicar no botão de trocar de tela
    // (botão que fica no lado direito da página, quase imperceptível)
    // o botão passa a funcionar na página de resultados, sem isso, este botão não funciona lá
    // o comportamento dos componentes do Sap Webdynpro é bastante estranho... vai enteder, né!
    // 17/08/2023 - parece que não será mais necessário essa etapa abaixo...
    // if (index == 0) {
    //   await this.clickByClassName(this.event, driver, "urSpTDP", 1, start, "Click para navegar para área direita da tela");
    //   await this.waitLocatedByClassName(this.event, driver, 'urSpTDN', 1000, start, 'Aguardar botão de navegar para área esquerda da tela');
    //   await this.clickByClassName(this.event, driver, "urSpTDN", 0, start, "Click para navegar para área esquerda da tela");
    // }

    await this.clearByClassName(this.event, driver, "lsField__input", 4, start, "Limpar caixa de texto do contrato");
    await this.clearByClassName(this.event, driver, "lsField__input", 6, start, "Limpar caixa de texto do FRS");
    await driver.sleep(1000);

    //se a seleção for por contrato
    if (parametroPesquisa == 1) {
      await this.sendKeyByClassName(this.event, driver, dados[index]["Número Contrato"], "lsField__input", 4, start, "Inserir número de contrato: " + dados[index]["Número Contrato"]);
    } else {
      await this.clickByClassName(this.event, driver, "urLink__text--standard", 6, start, "Inserir vários números de FRSs: " + dados[index]["Número de FRSs"]);

      var quantidadeDeFRSs = await this.getQuantidadeDeFRSs(dados[index]["Número de FRSs"]);

      if (quantidadeDeFRSs > 0) {
        var numeros_frs = dados[index]["Número de FRSs"];
        var FRSs = numeros_frs.toString().split(", ");
      } else {
        var FRSs = ["00000"]
      }

      await driver.sleep(1500);
      let iframeFRS = await this.getIndexIframeByText(this.event, driver, 'Seleção múltipla', start, 'Procurando pelo Iframe do pop up.')
      await driver.switchTo().defaultContent();
      await driver.switchTo().frame(iframeFRS.index);

      await driver.sleep(1000);
      await this.clickByClassName(this.event, driver, "lsTbarBtnStd", 3, start, "Limpar Seleção multipla FRS.");

      //adicionar novos campos para pesquisar mais de 5 FRS
      var auxLoopQuantidadeDeFRSs = 1
      await driver.sleep(1000);
      await this.clickByClassName(this.event, driver, "lsTbarBtnStd", 1, start, "Adicionando possibilidade de pesquisar mais FRSs");
      await this.clickByClassName(this.event, driver, "lsField__input", 0, start, "Selecionando a área para preencher o FRS");
      await driver.sleep(1000);
      while (auxLoopQuantidadeDeFRSs <= quantidadeDeFRSs - 5) {
        await this.clickByClassName(this.event, driver, "lsTbarBtnStd", 1, start, "Adicionando possibilidade de pesquisar mais FRSs");
        await this.clickByClassName(this.event, driver, "lsField__input", 0, start, "Selecionando a área para preencher o FRS");
        await driver.sleep(1000);
        auxLoopQuantidadeDeFRSs = auxLoopQuantidadeDeFRSs + 1;
      }

      auxLoopQuantidadeDeFRSs = 1
      while (auxLoopQuantidadeDeFRSs <= quantidadeDeFRSs) {
        await this.clickByClassName(this.event, driver, "lsField__input", auxLoopQuantidadeDeFRSs - 1, start, "Selecionando a área para preencher o FRS");

        await this.sendKeyByClassName(this.event, driver, "" + FRSs[auxLoopQuantidadeDeFRSs - 1], "lsField__input", auxLoopQuantidadeDeFRSs - 1, start, "Inserir número do FRS: " + FRSs[auxLoopQuantidadeDeFRSs - 1]);
        await this.sendKeyByClassName(this.event, driver, "" + FRSs[auxLoopQuantidadeDeFRSs - 1], "lsField__input", auxLoopQuantidadeDeFRSs - 1, start, "Inserir número do FRS: " + FRSs[auxLoopQuantidadeDeFRSs - 1]);

        auxLoopQuantidadeDeFRSs = auxLoopQuantidadeDeFRSs + 1;
      }

      await driver.sleep(1000);
      //await this.clickByClassName(this.event, driver, "lsTbarBtnStd", 4, start, "Click no botão OK");

      await this.clickByClassName(this.event, driver, "lsTbarBtnStd", 0, start, "Botão de verificar");
      var btOK = await this.waitLocatedByText(this.event, driver, 'OK', 20000, start, 'Verificar o botão OK.');

      if (btOK) {
        await this.clickButtonByText(this.event, driver, 'OK', 2, start, "Click no botão OK");
        await driver.sleep(3000);
        await driver.switchTo().defaultContent();
        await driver.sleep(3000);
      }
    }


    //TODO: Teste de função
    //await this.clickByClassNameAndText(this.event, driver, 'lsButton', 'Pesquisar', start, 'Buscando botão e tentando clicar');
    await this.clickButtonByText(this.event, driver, 'Pesquisar', 2, start, "Click no botão de pesquisa");


    //Verificar se vai encontrar o contrato
    await driver.sleep(1000);

    const verificarIDFParaLancar = await this.waitLocatedByClassName(this.event, driver, 'lsPopupWindow', 3000, start, 'Verificar se encontrou algum IDF para lançar.');

    if (verificarIDFParaLancar) {

      await driver.sleep(3000);
      await this.clickButtonByText(this.event, driver, 'OK', 0, start, "Click botão OK do pop up 'Não foram encontrados dados para essa pesquisa' - Tentativa 1");
      await this.clickButtonByText(this.event, driver, 'OK', 0, start, "Click botão OK do pop up 'Não foram encontrados dados para essa pesquisa' - Tentativa 2");

      await driver.switchTo().defaultContent();
      throw new Error("Contrato não localizado na pesquisa. Este contrato já foi avaliado ou não existe.");
    }

    await this.waitLocatedByText(this.event, driver, 'Exibir como', 60000, start, 'Aguardar Página de exibição (texto: "Exibir como")');

    await driver.sleep(1000);

    //Verifica se existe algum objeto com a classe de "Não selecionado" = "urST4LbUnselIcon"
    const veirifacaoCheckBoxSemFlag = await this.waitLocatedByClassName(this.event, driver, 'urST4LbUnselIcon', 3000, start, 'Verificar se check box para selecionar todos os registros já está preenchido.');

    // os casos em que tiver mais de uma linha para lançamento, a tabela não vem com o check para ser pressionado, mas caso so tenha um registro a tabela já vem com o check selecionado
    // portanto deve ser verificado se o check da tabela está selecionado ou não
    if (veirifacaoCheckBoxSemFlag) {
      await this.clickByClassName(this.event, driver, 'lsSTCellHeightInherit', 0, start, "Click no check box para selecionar todos os registros");
    }
    // await driver.sleep(1000);
    // await this.waitLocatedByText(this.event, driver, 'Selecionar tudo', 60000, start, 'Aguardar botão Selecionar tudo');
    // await this.clickByClassName(this.event, driver, 'urMnuTxt', 0, start, 'Click no botão Selecionar tudo');

    //teste
    if (isDev) {
      await driver.sleep(1000);
      await this.clickByClassName(this.event, driver, 'lsTbarBtnStd', 12, start, "Click no botão exibir ");
    }

    // //produção
    if (!isDev) {
      await driver.sleep(1000);
      //await this.clickByClassName(this.event, driver, 'lsTbarBtnStd', 7, start, "Click no combobox Avaliar");
      await this.clickByClassName(this.event, driver, 'lsButton--popupmenu', 4, start, "Click no combobox Avaliar");
      await driver.sleep(1000);
      await this.waitLocatedByText(this.event, driver, 'Responder Questionários', 1000, start, 'Aguardar botão Responder Questionários');
      await this.clickByClassName(this.event, driver, 'urMnuTxt', 0, start, "Click no botão Responder Questionários");
    }

    await driver.sleep(1000);
    if (await this.waitLocatedByText(this.event, driver, 'Somente o Fiscal pode responder ao questionário', 5000, start, 'Verificar se é exibido mensagem informando que não é fiscal do contrato.')) {
      await driver.sleep(1000);
      //await this.clickByClassName(this.event, driver, 'lsTbarBtnStd', 1, start, "Click no combobox Ir Para");
      await this.clickByClassName(this.event, driver, 'lsButton--popupmenu', 1, start, "Click no combobox Ir Para");
      await driver.sleep(1000);
      await this.waitLocatedByText(this.event, driver, 'Filtro de Pesquisa', 1000, start, 'Aguardar botão Filtro de Pesquisa');
      await this.clickByClassName(this.event, driver, 'urMnuTxt', 2, start, "Click no botão Filtro de Pesquisa");

      throw new Error("Somente o Fiscal pode responder ao questionário");
    }


    await this.waitLocatedByText(this.event, driver, "Ajuda", 10000, start, 'Verificar se existe a palavra Ajuda na página!');
    //
    // ** Loop de respostas
    //
    for (var a = index; a < (index + dados[index]["Quantidade Questões"]); a++) {
      // campo de Percentual Pergunta Respondida
      //let percentual = await driver.findElement(By.className("urPrInTxt1")).getText();
      await this.findQuestions(index, a, this.event, driver, dados, start);

      await driver.switchTo().parentFrame();
      // // Próxima questão
      console.log("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ a: " + a);
      console.log("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@: " + (index + dados[index]["Quantidade Questões"]));

      // clicar no próximo depois de clicar no check de resposta, com exceção a última questão, pois não tem próximo
      if (a != (index + dados[index]["Quantidade Questões"] - 1)) {
        var div = index % dados[index]["Quantidade Questões"];
        await this.clickButtonByText(this.event, driver, "Posterior", 0, start, "Click no botão Posterior - Índice: " + ((index + 1) + a) / (1 + (index % dados[index]["Quantidade Questões"])));

      } else {
        console.log("Apertar botão de Salvar!");


        // //produção
        if (!isDev) {
          if (isDev) {
            this.event.sender.send('responseRunIDFLog', "2# Modo Devesenvolvimento");
          } else {
            this.event.sender.send('responseRunIDFLog', "2# Modo Produção");
          }

          //colocar condição para gerente
          if (ator == "gerente") {
            await this.clickButtonByText(this.event, driver, "SALVAR + APROVAR", 0, start, "Click no botão Salvar");
          } else {
            await this.clickButtonByText(this.event, driver, "Salvar", 0, start, "Click no botão Salvar");
          }
        }
      }
    }

    // teste
    //Voltar para página de pesquisa
    if (isDev) {
      if (isDev) {
        this.event.sender.send('responseRunIDFLog', "3# Modo Devesenvolvimento");
      } else {
        this.event.sender.send('responseRunIDFLog', "3# Modo Produção");
      }

      await this.clickButtonByText(this.event, driver, "Voltar", 0, start, "Button Voltar - Execução é realizada somente no ambiente de desenvolvimento.");
    }

    await this.waitLocatedByText(this.event, driver, 'Exibir como', 60000, start, 'Aguardar Página de exibição (texto: "Exibir como")');

    await driver.sleep(1000);
    //await this.clickByClassName(this.event, driver, 'lsTbarBtnStd', 1, start, "Click no combobox Ir Para");
    await this.clickByClassName(this.event, driver, 'lsButton--popupmenu', 1, start, "Click no combobox Ir Para");
    await driver.sleep(1000);
    await this.waitLocatedByText(this.event, driver, 'Filtro de Pesquisa', 1000, start, 'Aguardar botão Filtro de Pesquisa');
    await this.clickByClassName(this.event, driver, 'urMnuTxt', 2, start, "Click no botão Filtro de Pesquisa");
  }

  async findQuestions(index, indexQuestion, event, driver, dados, start) {
    let a = 0;
    let flag = 0;
    let verifyCheckCount = 0;
    let flagCheck = 0;

    console.log("Análise de erro de dead object.");
    event.sender.send('responseRunIDFLog', "==========================================================================");
    event.sender.send('responseRunIDFLog', "Iniciando a pesquisa da pergunta:" + dados[indexQuestion]["Questionário"]);
    let iframe = await this.accessIframe(event, driver, "urFTxtV", start, 'Aguardar IFrame da questão.');

    if (iframe.flag) {
      while (a < dados[index]["Quantidade Questões"] && flag == 0) {
        await driver.switchTo().defaultContent();
        await driver.switchTo().frame(iframe.index);
        //urFTxtV
        if (a == 0) {
          if (await this.waitLocatedByText(event, driver, dados[indexQuestion]["Questionário"], 100, start, 'Pesquisar a provável questão - Aguardar Página do Questionários: ' + dados[indexQuestion]["Questionário"])) {
            flag = 1;

            while (verifyCheckCount < 5 && flagCheck == 0) {
              await driver.switchTo().defaultContent();
              this.event.sender.send('responseRunIDFLog', "Tentativa " & (verifyCheckCount + 1) & " de encontrar resposta:" + dados[indexQuestion]["Resposta"]);

              let iframePerguntas = await this.getIndexIframeByTextNoError(this.event, driver, dados[indexQuestion]["Resposta"], start, 'Procurando pelo Iframe da pergunta.')
              if (iframePerguntas.flag != 0) {
                await driver.switchTo().defaultContent();
                await driver.switchTo().frame(iframePerguntas.index);
              } else {
                await driver.switchTo().defaultContent();
              }

              let indexCheck = await this.getIndexByClassName(event, driver, "lsSelector--shrinked", dados[indexQuestion]["Resposta"],
                start,
                "Índice - " + dados[indexQuestion]["Resposta"]);

              await this.clickByClassName(event, driver, "lsSelector--shrinked", indexCheck, start, "Click na Resposta: " + dados[indexQuestion]["Resposta"]);
              //await this.clickByText(event, driver, dados[indexQuestion]["Resposta"], 0, start, "Click na Resposta: " + dados[indexQuestion]["Resposta"]);
              if (await this.waitLocatedByClassName(event, driver, "lsRadioButton--checked", 500, start, "Verificando se foi realizado o check") == true) {
                flagCheck = 1;
              }
              verifyCheckCount++;
            }
            if (!isDev) {
              // produção
              if (flagCheck == 0) {
                this.event.sender.send('responseRunIDFLog', "Tentativa de encontrar resposta esgotado: " + dados[indexQuestion]["Resposta"]);
                throw new Error("Não foi possível marcar a resposta: " + dados[indexQuestion]["Resposta"] + " - Verifique na planilha se esta resposta está de acordo com o formulário IDF.");

              }
            }
          }
        }
        if (flag == 0 && await this.waitLocatedByText(event, driver, dados[(index + a)]["Questionário"], 100, start, 'Aguardar Página do Questionários: ' + dados[(index + a)]["Questionário"])) {
          flag = 1;

          while (verifyCheckCount < 5 && flagCheck == 0) {
            await driver.switchTo().defaultContent();

            let iframePerguntas = await this.getIndexIframeByTextNoError(this.event, driver, dados[(index + a)]["Resposta"], start, 'Procurando pelo Iframe da pergunta.')
            if (iframePerguntas.flag != 0) {
              await driver.switchTo().defaultContent();
              await driver.switchTo().frame(iframePerguntas.index);
            } else {
              await driver.switchTo().defaultContent();
            }

            let indexCheck = await this.getIndexByClassName(event, driver, "lsSelector--shrinked", dados[(index + a)]["Resposta"],
              start,
              "Índice - " + dados[(index + a)]["Resposta"]);


            await this.clickByClassName(event, driver, "lsSelector--shrinked", indexCheck, start, "Click na Resposta: " + dados[(index + a)]["Resposta"]);
            if (await this.waitLocatedByClassName(event, driver, "lsRadioButton--checked", 500, start, "Verificando se foi realizado o check") == true) {
              flagCheck = 1;
            }
            verifyCheckCount++;
          }
          if (!isDev) {
            // // produção
            if (flagCheck == 0) {
              throw new Error("Não foi possível marcar a resposta: " + dados[(index + a)]["Resposta"] + " - Verifique na planilha se esta resposta está de acordo com o formulário IDF.");
            }
          }
        }


        a++;
      }
      if (flag == 0) {
        await driver.switchTo().defaultContent();

        await this.clickButtonByText(event, driver, "Voltar", 0, start, "Button Voltar - Foi clicado no botão voltar pois não foi localizado alguma pesqunta!");

        await this.waitLocatedByText(event, driver, 'Exibir como', 60000, start, 'Aguardar Página de exibição (texto: "Exibir como")');

        await driver.sleep(1000);
        //await this.clickByClassName(event, driver, 'lsTbarBtnStd', 1, start, "Click no combobox Ir Para");
        await this.clickByClassName(this.event, driver, 'lsButton--popupmenu', 1, start, "Click no combobox Ir Para");
        await driver.sleep(1000);
        await this.waitLocatedByText(event, driver, 'Filtro de Pesquisa', 1000, start, 'Aguardar botão Filtro de Pesquisa');
        await this.clickByClassName(event, driver, 'urMnuTxt', 2, start, "Click no botão Filtro de Pesquisa");

        event.sender.send('responseRunIDFErro', "==========================================================================");
        event.sender.send('responseRunIDFErro', "Erro na pergunta: " + ((index + 1) % dados[index]["Quantidade Questões"]) + " do formulário do IDF. Não foi possível achar correspondência.");
        event.sender.send('responseRunIDFErro', "Dica: Veja se a pergunta está exatamente como no formulário do IDF, verifique se no final e no início da pergunta do excel tem algum espaço ou se os devidos espaços entre as palavras estão semelhante ao do formulário do IDF. É importante que o texto no excel esteja exatamente igual ao do formulário do IDF.");
        throw new Error("Questionário Sem Resposta! Localize e corrija no excel do IDF a questão exibida no formulário do IDF SAP aberto no Firefox. Provavelmente, não há essa questão no excel.");
      }
    }
  }

  async getIndexByClassName(event, driver, className, text, start, logDescription) {
    let contLoop = 0;
    let flag = 0;
    let classes = await driver.findElements(By.className(className));

    event.sender.send('responseRunIDFLog', "Valor da variável classes.length" + classes.length);
    while (contLoop < classes.length && flag == 0) {
      let textFromClasse = await classes[contLoop].getText();
      let textoFormatado = textFromClasse.replace(/[\r\n]+/g, '').replace(/> /g, '>').replace(/<[^>]*>/g, '');
      //event.sender.send('responseRunIDFLog', "Valor da variável textFromClasse " + textoFormatado + " | Valor da variável text " + text);
      if (text == textoFormatado) {
        flag = 1;
        let message = moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - Index da resposta: " + contLoop + " " + textoFormatado;
        console.log(message);
        event.sender.send('responseRunIDFLog', message);
      } else {
        contLoop++;
      }
    }

    if (flag == 0) {

      await this.clickButtonByText(event, driver, "Voltar", 0, start, "Button Voltar - Quantidade de tentativas de busca do class name esgotado.");

      await this.waitLocatedByText(event, driver, 'Exibir como', 60000, start, 'Aguardar Página de exibição (texto: "Exibir como")');

      await driver.sleep(1000);
      //await this.clickByClassName(event, driver, 'lsTbarBtnStd', 1, start, "Click no combobox Ir Para");
      await this.clickByClassName(this.event, driver, 'lsButton--popupmenu', 1, start, "Click no combobox Ir Para");
      await driver.sleep(1000);
      await this.waitLocatedByText(event, driver, 'Filtro de Pesquisa', 1000, start, 'Aguardar botão Filtro de Pesquisa');
      await this.clickByClassName(event, driver, 'urMnuTxt', 2, start, "Click no botão Filtro de Pesquisa");


      throw new Error("Índice de resposta não localizado! " + logDescription);
    }
    return contLoop;
  }

  async checkByText(event, driver, text, indexText, start, logDescription) {
    await driver.findElement(By.xpath("//*[text()='" + text + "']")).then(async function (element) {
      await element.findElement(By.xpath("./..//input[@class='lsSelector__inputTag']")).then(async function (elemt) {
        await driver.sleep(2000);
        elemt.click().then(function () {
          let message = moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - " + logDescription;
          console.log(message);
          event.sender.send('responseRunIDFLog', message);
        });
      });
      console.log(logDescription + " ", Date.now() - start);
    });
  }


  async sendKeyByClassName(event, driver, key, className, indexClassName, start, logDescription) {
    await driver.findElements(By.className(className)).then(async function (elements) {
      await driver.sleep(500);
      elements[indexClassName].sendKeys(key).then(function () {
        let message = moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - " + logDescription;
        console.log(message);
        event.sender.send('responseRunIDFLog', message);
      });
      console.log(logDescription + " ", Date.now() - start);
    });
  }

  async clickByClassName(event, driver, className, indexClassName, start, logDescription) {
    await driver.findElements(By.className(className)).then(async function (elements) {
      await driver.sleep(500);
      elements[indexClassName].click().then(function () {
        let message = moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - " + logDescription;
        console.log(message);
        event.sender.send('responseRunIDFLog', message);
      });
      console.log(logDescription + " ", Date.now() - start);
    });
  }

  async clickByClassNameAndText(event, driver, className, textButton, start, logDescription) {
    await driver.findElements(By.className(className) && By.xpath("//*[text()='" + textButton + "']")).then(async function (elements) {
      await driver.sleep(500);
      elements[indexClassName].click().then(function () {
        let message = moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - " + logDescription;
        console.log(message);
        event.sender.send('responseRunIDFLog', message);
      });
      console.log(logDescription + " ", Date.now() - start);
    });
  }

  //async clickByClassNameAndText(event, driver, className, textButton, start, logDescription) {
  //  await driver.findElements(By.className(className) && By.xpath("//*[text()='" + textButton +"']")).then(async function (elements) {
  //    await driver.sleep(500);
  //    //for (var a = 0; a < elements.length; a++) {
  //    //  await driver.findElement(By.xpath("//*[text()='" + textButton + "']"))
  //    //  if (elements[a].text == textButton) {
  //    //    elements[a].click().then(function () {
  //    //      let message = moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - " + logDescription;
  //    //      console.log(message);
  //    //      event.sender.send('responseRunIDFLog', message);
  //    //    });
  //    //  }
  //    elements[a].click().then(function () {
  //      let message = moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - " + logDescription;
  //      console.log(message);
  //      event.sender.send('responseRunIDFLog', message);
  //    }
  //  });
  //  console.log(logDescription + " ", Date.now() - start);
  //}

  async clearByClassName(event, driver, className, indexClassName, start, logDescription) {
    await driver.findElements(By.className(className)).then(async function (elements) {
      await driver.sleep(2000);
      elements[indexClassName].clear().then(function () {
        let message = moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - " + logDescription;
        console.log(message);
        event.sender.send('responseRunIDFLog', message);
      });
      console.log(logDescription + " ", Date.now() - start);
    });
  }

  async clickById(event, driver, id, start, logDescription) {
    await driver.findElement(By.id(id)).then(async function (element) {
      await driver.sleep(2000);
      element.click().then(function () {
        let message = moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - " + logDescription;
        console.log(message);
        event.sender.send('responseRunIDFLog', message);
      });
      // driver.sleep(2000);
      console.log(logDescription + " ", Date.now() - start);
    });
  }

  async clickByText(event, driver, text, indexText, start, logDescription) {
    await driver.findElement(By.xpath("//*[text()='" + text + "']")).then(async function (element) {
      await element.findElement(By.xpath("./..")).then(async function (elemt) {
        await driver.sleep(500);
        elemt.click().then(function () {
          let message = moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - " + logDescription;
          console.log(message);
          event.sender.send('responseRunIDFLog', message);
        });
      });
      console.log(logDescription + " ", Date.now() - start);
    });
  }

  async clickButtonByText(event, driver, text, indexText, start, logDescription) {
    await driver.findElement(By.xpath("//*[text()='" + text + "']")).then(async function (element) {
      console.log(await element.innerHTML);
      await element.findElement(By.xpath("./../../..")).then(async function (elemt) {
        await driver.sleep(500);
        elemt.click().then(function () {
          let message = moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - " + logDescription;
          console.log(message);
          event.sender.send('responseRunIDFLog', message);
        });
      });
      console.log(logDescription + " ", Date.now() - start);
    });
  }

  async waitLocatedByTextToClick(event, driver, text, start, logDescription) {
    await driver
      .wait(
        until.elementLocated(By.xpath("//*[text()='" + text + "']"), 60000)
      )
      .then(async function () {
        await driver.findElement(By.xpath("./..")).then(async function (element) {
          await driver.sleep(2000);
          element.click().then(function () {
            let message = moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - " + logDescription;
            console.log(message);
            event.sender.send('responseRunIDFLog', message);
            return true;
          });
          // driver.sleep(2000);
          console.log(logDescription + " ", Date.now() - start);
        });
      }, function (err) {
        if (err.state && err.state === 'no such element') {
          let message = moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - " + logDescription;
          console.log(message);
          event.sender.send('responseRunIDFLog', message);
          return false;

        } else {
          let message = moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - " + logDescription;
          console.log(message);
          event.sender.send('responseRunIDFLog', message);
          return false;
        }
      });
  }
  async waitLocatedByIdToClick(event, driver, id, start, logDescription) {
    await driver
      .wait(
        until.elementLocated(By.id(id), 10000)
      )
      .then(async function () {
        await driver.findElement(By.id(id)).then(async function (element) {
          await driver.sleep(2000);
          element.click().then(function () {
            let message = moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - " + logDescription;
            console.log(message);
            event.sender.send('responseRunIDFLog', message);
            return true;
          });
          // driver.sleep(2000);
          console.log(logDescription + " ", Date.now() - start);
        });
      }, function (err) {
        if (err.state && err.state === 'no such element') {
          let message = moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - " + logDescription;
          console.log(message);
          event.sender.send('responseRunIDFLog', message);
          return false;

        } else {
          let message = moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - " + logDescription;
          console.log(message);
          event.sender.send('responseRunIDFLog', message);
          return false;
        }
      });
  }

  async waitLocatedById(event, driver, id, start, logDescription) {
    return await driver.wait(this.elementIsPresent(driver, By.id(id)), 10000)
      .then(async function () {
        let message = moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - " + logDescription;
        console.log(message);
        event.sender.send('responseRunIDFLog', message);
        return true;

      }, function (err) {
        if (err.state && err.state === 'no such element') {
          let message = moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - Não foi possível localizar! - " + logDescription;
          console.log(message);
          event.sender.send('responseRunIDFLog', message);
          return false;

        } else {
          let message = moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - Não foi possível localizar! - " + logDescription;
          console.log(message);
          event.sender.send('responseRunIDFLog', message);
          return false;
        }
      });
  }


  async waitLocatedByText(event, driver, text, delay, start, logDescription) {
    return await driver.wait(this.elementIsPresent(driver, By.xpath("//*[text()='" + text + "']")), delay)
      .then(async function () {
        await driver.sleep(2000);
        let message = moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - " + logDescription;
        console.log(message);
        event.sender.send('responseRunIDFLog', message);
        return true;

      }, function (err) {
        if (err.state && err.state === 'no such element') {
          let message = moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - Não foi possível localizar! - " + logDescription;
          console.log(message);
          console.log(err);
          event.sender.send('responseRunIDFLog', message);
          return false;

        } else {
          let message = moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - Não foi possível localizar! - " + logDescription;
          console.log(message);
          console.log(err);
          event.sender.send('responseRunIDFLog', message);
          return false;

        }
      });
  }

  async accessIframe(event, driver, className, start, logDescription) {
    let count = 0;
    let index = 0;
    let flag = 0;

    await driver.sleep(200);
    let elements = await driver.findElements(By.xpath("//iframe"));
    let countIFrame = elements.length;
    while (count < (countIFrame * 5) && flag == 0) {
      await driver.switchTo().defaultContent();
      await driver.switchTo().frame(count % countIFrame);

      if (await this.waitLocatedByClassName(event, driver, className, 1000,
        start, logDescription)) {
        flag = 1;
        index = (count % countIFrame);
      }

      count++;
    }

    if (flag == 0) {
      await this.clickButtonByText(event, driver, "Voltar", 0, start, "Button Voltar - Quantidade de tentativa de achar Iframe esgotada.");

      await this.waitLocatedByText(event, driver, 'Exibir como', 60000, start, 'Aguardar Página de exibição (texto: "Exibir como")');

      await driver.sleep(1000);
      //await this.clickByClassName(event, driver, 'lsTbarBtnStd', 1, start, "Click no combobox Ir Para");
      await this.clickByClassName(this.event, driver, 'lsButton--popupmenu', 1, start, "Click no combobox Ir Para");
      await driver.sleep(1000);
      await this.waitLocatedByText(event, driver, 'Filtro de Pesquisa', 1000, start, 'Aguardar botão Filtro de Pesquisa');
      await this.clickByClassName(event, driver, 'urMnuTxt', 2, start, "Click no botão Filtro de Pesquisa");


      throw new Error("Limite de tentativa de acesso ao IFrame. Classe: " + className);
    }

    return { 'flag': flag, 'index': index };
  }

  async getHTML(event, driver, className) {
    await driver.executeScript(function () {
      //return document.querySelector("body").innerHTML;
      return document.querySelector("html").innerHTML;
    }).then(function (innerHTML) {
      console.log(innerHTML)
      //check content here 
    });
  }

  async getIndexIframeByText(event, driver, text, start, logDescription) {
    let count = 0;
    let index = 0;
    let flag = 0;

    await driver.sleep(200);
    let elements = await driver.findElements(By.xpath("//iframe"));
    let countIFrame = elements.length;
    while (count < (countIFrame * 5) && flag == 0) {
      await driver.switchTo().defaultContent();
      await driver.switchTo().frame(count % countIFrame);

      if (await this.waitLocatedByText(event, driver, text, 200,
        start, logDescription)) {
        flag = 1;
        index = (count % countIFrame);
      }
      count++;
    }

    if (flag == 0) {

      throw new Error("Limite de tentativa de acesso ao IFrame. Text: " + text);
    }

    return { 'flag': flag, 'index': index };
  }

  async getIndexIframeByTextNoError(event, driver, text, start, logDescription) {
    let count = 0;
    let index = 0;
    let flag = 0;

    await driver.sleep(200);
    let elements = await driver.findElements(By.xpath("//iframe"));
    let countIFrame = elements.length;
    while (count < (countIFrame * 5) && flag == 0) {
      await driver.switchTo().defaultContent();
      await driver.switchTo().frame(count % countIFrame);

      if (await this.waitLocatedByText(event, driver, text, 200,
        start, logDescription)) {
        flag = 1;
        index = (count % countIFrame);
      }
      count++;
    }

    return { 'flag': flag, 'index': index };
  }

  async waitLocatedByClassName(event, driver, className, delay, start, logDescription) {
    return await driver.wait(this.elementIsPresent(driver, By.className(className)), delay)
      .then(async function () {
        await driver.sleep(500);
        let message = moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - " + logDescription;
        console.log(message);
        event.sender.send('responseRunIDFLog', message);
        return true;

      }, function (err) {
        if (err.state && err.state === 'no such element') {
          let message = moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - Não foi possível localizar! - " + logDescription;
          console.log(message);
          event.sender.send('responseRunIDFLog', message);
          return false;

        } else {
          let message = moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - Não foi possível localizar! - " + logDescription;
          console.log(message);
          event.sender.send('responseRunIDFLog', message);
          return false;

        }
      });
  }

  elementIsPresent(driver, locator) {
    return new Condition('for element to be located ' + locator, function (driver) {
      return driver.findElements(locator).then(function (elements) {
        console.log("for no element to be located");
        console.log(elements.length > 0);
        return elements.length > 0;
      });
    });
  }

  async getQuantidadeDeFRSs(numeros_frs) {
    if (numeros_frs != "" && numeros_frs != null) {
      var FRSs = numeros_frs.toString().split(", ");
      return FRSs.length;
    }
    return 0;
  }
}

module.exports = RPA;
