const ExcelApi = require("../services/excel.js");
const ErrorMessage = require("../services/errorMessage.js");

const notifier = require("node-notifier");
const moment = require('moment');
const StarterRPA = require("./starterRPA.js");

async function FactoryRequestIDF() {

  const readerScriptIDF = async function (event, idf) {
    const excelService = new ExcelApi(idf.enderecoRede, idf.parametroPesquisa);

    notifier.notify({
      title: "Lança IDF",
      message: "O script está carregando os arquivos!",
      icon: __dirname + "/../src/images/icon-notify.png",
    });

    try {
      event.sender.send('responseRunIDFLog', moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - " + "Iniciando leitura dos arquivos.");
      const response = await excelService.readSheetIDF();
      event.sender.send('responseReadIDF', response);
      event.sender.send('responseRunIDFLog', moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - " + "Arquivos lidos com sucesso.");

    } catch (e) {
      const errorMessage = new ErrorMessage(e, "read-excel");
      event.sender.send('responseReadIDF', {
        mensagem: "Erro ao carregar a planilha! " + errorMessage.getErrorMessage(),
        feedback: "erro",
        show: true,
      });

      let message = moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - " + e.message;
      console.log(message);
      event.sender.send('responseRunIDFErro', message);
      console.log(e);
      notifier.notify({
        title: "Lança IDF",
        message: "Erro ao carregar a planilha! " + errorMessage.getErrorMessage(),
        icon: __dirname + "/../src/images/icon-notify.png",
      });
    }
  }

  const actFiscalScriptIDF = async function (event, idf, dados, parametros) {
    notifier.notify({
      title: "Lança IDF",
      message: "Script inicializando!",
      icon: __dirname + "/../src/images/icon-notify.png",
    });

    try {

      const starter = StarterRPA();
      await starter.init(event, idf, dados, parametros, "fiscal");

      event.sender.send('responseRunIDF', {
        mensagem: "Script Finalizado!",
        feedback: "sucesso",
        show: true,
      });

      let message = moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - Script finalizado.";
      event.sender.send('responseRunIDFLog', message);

    } catch (e) {

      const errorMessage = new ErrorMessage(e, 'run-script');
      event.sender.send('responseRunIDF', {
        mensagem: "Erro ao rodar o Script! " + errorMessage.getErrorMessage(),
        feedback: "erro",
        show: true,
      });

      let message = moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - " + e.message;
      event.sender.send('responseRunIDFErro', message);

      notifier.notify({
        title: "Lança IDF",
        message: "Erro ao rodar o Script! " + errorMessage.getErrorMessage(),
        icon: __dirname + "/../src/images/icon-notify.png",
      });
    }
  }

  const actGerenteScriptIDF = async function (event, idf, dados, parametros) {
    notifier.notify({
      title: "Lança IDF",
      message: "Script inicializando!",
      icon: __dirname + "/../src/images/icon-notify.png",
    });

    try {

      const starter = StarterRPA();
      await starter.init(event, idf, dados, parametros, "gerente");

      event.sender.send('responseRunIDF', {
        mensagem: "Script Finalizado!",
        feedback: "sucesso",
        show: true,
      });

      let message = moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - Script finalizado.";
      event.sender.send('responseRunIDFLog', message);

    } catch (e) {

      const errorMessage = new ErrorMessage(e, 'run-script');
      event.sender.send('responseRunIDF', {
        mensagem: "Erro ao rodar o Script! " + errorMessage.getErrorMessage(),
        feedback: "erro",
        show: true,
      });

      let message = moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - " + e.message;
      event.sender.send('responseRunIDFErro', message);

      notifier.notify({
        title: "Lança IDF",
        message: "Erro ao rodar o Script! " + errorMessage.getErrorMessage(),
        icon: __dirname + "/../src/images/icon-notify.png",
      });
    }
  }

  return {
    readerScriptIDF,
    actFiscalScriptIDF,
    actGerenteScriptIDF
  }
}

module.exports = FactoryRequestIDF;