const RPA = require("./rpa.js");
const StatusRelatorio = require("../services/statusRelatorio.js");
const moment = require('moment');

function StarterRPA() {

  async function init(event, idf, dados, parametros, ator) {
    const rpaIDF = new RPA(event);
    //const excelData = await getExcelData();
    const driver = await rpaIDF.initProcess();
    let objs = new StatusRelatorio(parametros);

    let contSheet = 0;
    let index = 0;
    
    while (contSheet < parametros.length) {
      try {
        await rpaIDF.script(
          driver,
          dados,
          index,
          idf.parametroPesquisa,
          ator
        );

        objs.alterStatus(dados[index]["Nome do Relatório"], "Realizado");
        event.sender.send('responseStatusObjeto', objs.getStatus());
        event.sender.send('responseProgressoBar', objs.getProgressObjeto());
        event.sender.send('responseProgressDone', objs.countObjetoDone());
      } catch (e) {
        objs.alterStatus(dados[index]["Nome do Relatório"],
          (e.message == "Parâmetro não localizado na pesquisa. Este contrato ou FRSs já foi avaliado ou não existe." ?
            "Contrato/FRSs já avaliado ou não existe"
            : "Erro ao rodar script"));
        event.sender.send('responseStatusObjeto', objs.getStatus());
        event.sender.send('responseProgressoBar', objs.getProgressObjeto());
        event.sender.send('responseProgressDone', objs.countObjetoDone());

        let message = moment(Date.now()).format("DD/MM/YYYY HH:mm:ss") + " - " + e.message;
        event.sender.send('responseRunIDFErro', message + " - Erro referente ao relatório " + dados[index]["Nome do Relatório"]);
        event.sender.send('responseRunIDF', {
          mensagem: "Erro ao rodar o Script! ",
          feedback: "erro",
          show: true,
        });
      }

      index = index + dados[index]["Quantidade Questões"];
      contSheet++;
    }
  }

  return { init }
}

module.exports = StarterRPA;