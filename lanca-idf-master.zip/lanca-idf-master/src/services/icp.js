var userAgent = navigator.userAgent.toLowerCase();
let ipc;
if (userAgent.indexOf(' electron/') > -1) {
  ipc = window.require("electron").ipcRenderer;

}
export default ipc;