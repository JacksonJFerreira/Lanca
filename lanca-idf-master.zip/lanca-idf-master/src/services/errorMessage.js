class ErrorMessage {
  constructor(e, action) {
    this.ex = e;
    this.action = action;
  }

  getErrorMessage() {
    if (this.action == "read-excel") {
      if (this.ex.message.includes('no such file or directory')) {
        return "Diretório das planilhas está errado, portanto não foi encontrado.";
      } else if (this.ex.message.includes("Can't find end of central directory")) {
        return "Há alguma planilha aberta no diretório informado.";
      } else if (this.ex.message.includes("Erro no preenchimento da planilha")) {
        return this.ex.message;
      } else if (this.ex.message == "Cannot read property 'name' of undefined") {
        return "Erro inesperado. Verifique se a(s) planilha(s) contem a aba de Contrato e FRSs";
      } else {
        return "Erro inesperado. Verifique se só existe planilhas IDF no diretório mencionado..";
      }
    } else if (this.action == "run-script") {
      if (this.ex.message.includes("(os error 5)")) {
        return "Houve uma demora para carregar a página no Firefox, favor clicar novamente no butão de rodar Script.";
      } else if (this.ex.message.includes("Unable to locate")) {
        return "Um elemento da página não foi possível ser encontrado!";
      } else if (this.ex.message.includes("Somente o Fiscal pode responder ao questionário")) {
        return "Um dos contratos não pertence à você como Fiscal!";
      } else {
        return "Erro inesperado. Houve algum problema ao rodar o script.";
      }
    }
  }
}

module.exports = ErrorMessage;