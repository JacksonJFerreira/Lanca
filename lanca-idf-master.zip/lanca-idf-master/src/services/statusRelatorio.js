class StatusRelatorio {
  constructor(objetos) {
    this.objetos = objetos;
    // contratos = [{contrato: '', status: 'Realizado' / 'Não Realizado' / 'Já Avaliado Anteriormente ou Não Existente'}]
  }

  alterStatus(relatorio, newStatus) {
    var contIndex = 0;
    this.objetos.map((obj, index) => {
      if (obj.parametro == relatorio && obj.status == "Não Realizado") {
        contIndex = index;
      }
    })
    this.objetos.map((obj, index) => {
      if (obj.parametro == relatorio && obj.status != "Não Realizado") {
        contIndex = index;
      }
    })

    this.objetos[contIndex] = { 'parametro': relatorio, 'status': newStatus }
  }

  getStatus() {
    return this.objetos;
  }

  getProgressObjeto() {
    //return this.countContratoDone() + ' / ' + this.contratos.length;
    return (this.countObjetoDone() / this.objetos.length) * 100;
  }

  countObjetoDone() {
    var contDone = 0;
    this.objetos.map((objeto) => {
      if (objeto.status == 'Realizado') {
        contDone++;
      }
    })

    return contDone
  }
}

module.exports = StatusRelatorio;