class ProgressCalculator {
  constructor(denominador) {
    this.denominador = denominador;
    this.numerador = 0;
  }

  sumProgress(valueInclude) {
    this.numerador = this.numerador + valueInclude;
  }

  getPercent() {
    percent = (this.numerador / this.denominador) * 100;
    return percent;
  }
}

module.exports = ProgressCalculator;