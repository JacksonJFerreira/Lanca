const ExcelJS = require('exceljs');
const fs = require('fs');
const ErrorMessage = require('./errorMessage');

class ExcelApi {
  constructor(path, parameter ) {
    this.path = path;
    this.parameter = parameter;
  }

  async readSheetIDF() {
    const workbook = new ExcelJS.Workbook();
    const parameter = this.parameter;

    let filesDir = [];
    await this.getFilesOfDir(this.path).then((files) => {
      filesDir = files;
    });

    let obj = [];
    let errorFormat = {
      flag: 0,
      mensagem: "Erro no preenchimento da planilha: ",
    };

    var index = 0;
    
    for (const file of filesDir) {
      var parametros = await this.readSheetParametroPesquisaIDF(file);
      await workbook.xlsx.readFile(this.path + "\\" + file)
        .then(function (table) {
          var worksheet = workbook.getWorksheet(table.worksheets[0].name);
          const columns = worksheet.getRow(1).values;

          if(index == 0){
            if (parameter==1){
              index = parametros.contrato.toString().indexOf("4600");
            }else{            
              index = parametros.FRSs == "";
            }
          }

          let lastQuestionText = '';
          let contRows = 0;

          //trecho de código responsável por percorrer as linhas da planilha até encontrar a nova pergunta
          worksheet.eachRow({ includeEmpty: true, defval: "" }, function (row) {
            let question = row.getCell(7).value;

            if (lastQuestionText != question && question != null) {
              lastQuestionText = question;
              contRows++;
            }
          });

          // end getCoutRows
          let contRowAnser = 0;
          let lastQuestionInserted = '';
          let lastQuestion = '';

          console.log(columns);
          //exlcuir colunas que não tem necessidade
          columns.splice(0, 1);
          columns.splice(1, 1);
          columns.splice(2, 1);
          columns.splice(3, 1);
          columns.splice(4, 2);
          columns.splice(5, 1);
          columns.splice(6, 1);
          columns.splice(6, (columns.length - 7));

          const mes = columns[4];

          //editar nome das colunas
          columns[0] = "Macrocritério";
          columns[1] = "Critério";
          columns[2] = "Subcritério";
          columns[3] = "Questionário";
          columns[4] = "Resposta Selecionada";
          columns[5] = "Resposta";
          columns[6] = "Mês";

          //criar novas colunas
          columns.push("Nome do Relatório");
          columns.push("Quantidade Questões");
          columns.push("Ordem da Resposta");
          columns.push("Número Contrato");
          columns.push("Número de FRSs");

          console.log(columns);

          let cells = {};

          worksheet.eachRow({ includeEmpty: true, defval: "" }, function (row, rowIndex) {
            // verificação de erro
            if ((row.getCell(10).value == "X" || row.getCell(10).value == "x") && lastQuestionInserted == row.getCell(7).value) {
              errorFormat['flag'] = 1;
              //condição indevida - há mais de uma linha respondida (há mais de uma resposta) para a mesma pergunta
              errorFormat['mensagem'] = errorFormat['mensagem'] + "\n" +
                'Há mais de uma resposta preechida para a pergunta "' + lastQuestionInserted + '" do arquivo ' + file + '; ';
              console.log("condição indevida - há mais de uma linha respondida para a mesma pergunta");
            }

            // verificação de erro
            if (lastQuestion != row.getCell(7).value && lastQuestionInserted != lastQuestion && rowIndex > 2) {
              errorFormat['flag'] = 1;
              errorFormat['mensagem'] = errorFormat['mensagem'] + "\n" +
                'Não há resposta preechida para a pergunta "' + lastQuestion + '" do arquivo ' + file + '; ';
              console.log("condição indevida - não há resposta para a pergunta");
              //condição indevida - não há resposta para a pergunta
            }

            if (lastQuestion != row.getCell(7).value) {
              contRowAnser = 0;
            }

            if (row.getCell(10).value == "X" || row.getCell(10).value == "x") {
              lastQuestionInserted = row.getCell(7).value;

              cells[columns[0]] = row.getCell(1).value;
              cells[columns[1]] = row.getCell(3).value;
              cells[columns[2]] = row.getCell(5).value;
              cells[columns[3]] = " " + row.getCell(7).value + " ";
              cells[columns[4]] = row.getCell(10).value;
              cells[columns[5]] = row.getCell(12).value;
              cells[columns[6]] = mes;
              cells[columns[7]] = file;
              // -2 becouse the header row. There are two verification that add +1 in the contRows.
              cells[columns[8]] = contRows - 1;
              cells[columns[9]] = contRowAnser;
              cells[columns[10]] = (parametros.contrato == null || parametros.contrato == undefined || parametros.contrato == "" ? "0000000000" : parametros.contrato);
              cells[columns[11]] = (parametros.FRSs == null || parametros.FRSs == undefined || parametros.FRSs == "" ? "0000000000" : parametros.FRSs);

              //console.log(cells);
              obj.push(cells);
              cells = {};
              contRowAnser = (-1);
            }
            if (rowIndex > 1) {
              contRowAnser++;
            }
            lastQuestion = row.getCell(7).value;
          })

        });

    }

    //Verifica se o parâmetro de pesquisa selecionado pelo usuário encontrou correspondência nos arquivos
    if(index<0){
      errorFormat['flag'] = 1;
      errorFormat['mensagem'] = errorFormat['mensagem'] + "\n" +
        'O parâmetro de pesquisa da planilha não corresponde ao que foi selecionado preencido na segunda aba do relatório. Favor revisar a segunda aba da planilha do IDF';
    }

    if (errorFormat['flag'] == 1) {
      throw new Error(errorFormat['mensagem']);
    }

    return obj;

  }

  async readSheetParametroPesquisaIDF(file) {
    const workbook = new ExcelJS.Workbook();
    const parametros = {
      contrato: "",
      FRSs: ""
    }

    await workbook.xlsx.readFile(this.path + "\\" + file)
      .then(function (table) {
        var worksheet = workbook.getWorksheet(table.worksheets[1].name);

        const segundaLinha = worksheet.getRow(2).values;

        // o número de contrato deverá estar na segunda linha e primeira coluna, da segunda aba da planilha Excel
        parametros.contrato = (segundaLinha[1] == undefined || segundaLinha[1] == null || segundaLinha == undefined ? "0000000" : segundaLinha[1] );

        worksheet.eachRow({ includeEmpty: true, defval: "" }, function (row, rowIndex) {
          if(rowIndex == 2){
            parametros.FRSs = row.getCell(2).value;
          }

          if(rowIndex > 2){
            parametros.FRSs = parametros.FRSs + ", " + row.getCell(2).value;
          }
        })

      })

      return parametros;
}

  async getFilesOfDir(dir) {
    return new Promise(function (resolve, reject) {
      fs.readdir(dir, function (err, filenames) {
        if (err)
          reject(err);
        else
          resolve(filenames);
      });
    });
  }

  async getContrato(filename) {
    var filenameSplited = filename.split("_");
    return filenameSplited[2];
  }

  async getMes(filename) {
    var filenameSplitedUnderLine = filename.split("_");
    var filenameSplitedEspaco = filenameSplitedUnderLine[3].split(" ");
    filenameSplitedEspaco = filenameSplitedEspaco[0].split(".");
    return filenameSplitedEspaco[0];
  }
}

module.exports = ExcelApi;