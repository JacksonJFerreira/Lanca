import styled from "styled-components";

export const LogWrapper = styled.div`
  display: flex;
  color: #fff;
  margin: 20px 0px 10px 0px;
  justify-content: flex-end;
`;

export const LogFieldSet = styled.div`
  background: #fff;
  color: #fff;
  border: 1px solid #dee2e6;
  height: 260px;
  padding: 20px;
  width: 100%;
  overflow-y: auto;
`;

export const LogLegendText = styled.p`
  color: #488d80;
  width: 100%;
  margin: 0px;
  white-space: pre-wrap;
`;
