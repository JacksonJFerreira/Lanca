import React from "react";
import * as S from "./styled";

const Log = ({ contents }) => {

  return (
    <S.LogWrapper>
      <S.LogFieldSet id="log">
        {contents.map((content) => {
          return (
            <S.LogLegendText>
              {content}
            </S.LogLegendText>
          )
        })}
      </S.LogFieldSet>
    </S.LogWrapper>
  );
};

export default Log;
