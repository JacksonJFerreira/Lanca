import React from 'react';
import * as S from "./styled"

const ReadMe = () => {
  return (
    <>
      <S.ReadMeWrapper>
        <S.ReadMeDisplay>
          <S.ReadMeText><S.ReadMeLink href="portalssub.petrobras.biz/">Leia Me</S.ReadMeLink></S.ReadMeText>
        </S.ReadMeDisplay>
      </S.ReadMeWrapper>
    </>
  );
}

export default ReadMe;