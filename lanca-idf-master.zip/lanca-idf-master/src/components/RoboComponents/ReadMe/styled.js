import styled from 'styled-components';

export const ReadMeWrapper = styled.div`
  width: 100%;
  height: 2.5rem;
  color: #2C5E4F;
  
`

export const ReadMeDisplay = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: flex-end;
  height: 100%;
`
export const ReadMeText = styled.div`
  margin: 5px 20px 5px 20px;
`

export const ReadMeLink = styled.a`

`
