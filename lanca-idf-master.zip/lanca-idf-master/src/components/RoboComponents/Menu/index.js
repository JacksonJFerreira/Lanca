import React from 'react';
import * as S from "./styled"
import logo from "../../images/logo_inovação.png"

const Menu = () => {
  return (
    <>
      <S.MenuWrapper>
        <S.MenuNav>
          <S.MenuGroupItem>
            <S.MenuTitle>{"Menu"}
            </S.MenuTitle>
          </S.MenuGroupItem>

          <S.MenuGroupItem>
            <S.MenuItem>{"Avaliação IDF"}
            </S.MenuItem>
          </S.MenuGroupItem>

        </S.MenuNav>
        <S.MenuFooter>
          <S.MenuLogoInov src={logo}></S.MenuLogoInov>
          <S.MenuFooterText>{"V.: 1.0.0"}</S.MenuFooterText>
        </S.MenuFooter>
      </S.MenuWrapper>
    </>
  );
}

export default Menu;