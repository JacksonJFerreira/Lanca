import styled from 'styled-components';

export const MenuWrapper = styled.div`
  display: flex;
  flex-direction: column;
  width: 25%;
  height: 95vh;
  color: #006298;
  background: #FAFAFA;
  box-shadow: 0px 9px 18px rgba(0, 0, 0, 0.18), 0px 5.5px 5px rgba(0, 0, 0, 0.24);

  justify-content: space-between;
  margin-right: 10px;
  padding: 20px;
`

export const MenuNav = styled.div`
  background: none;
`

export const MenuGroupItem = styled.div`
background: none;

`
export const MenuTitle = styled.div`

font-family: "Trebuchet MS";
font-style: normal;
font-weight: bold;
font-size: 14px;
line-height: 24px;
background: none;
`
export const MenuItem = styled.a`
background: none;
`

export const MenuFooter = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  background: none;
`
export const MenuFooterText = styled.div`
  padding-top: 20px;
  background: none;
`

export const MenuLogoInov = styled.img`
  width: 40px;
  height: 40px;
  background: none;
`
