import styled from 'styled-components';

export const PopupWrapper = styled.div`
  display: ${props => (props.visible == true ? "block" : "none")};
  position: fixed;
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
`

export const PopupContent = styled.div`
  display: flex;
  flex-direction: column;
  
  background-color: #fefefe;
  margin: 100px auto;
  padding: 0px 20px;
  border: 1px solid #888;
  width: 50%;
  height: 300px;
`

export const PopupHeader = styled.div`
  display: flex;
  flex-direction: column;
`
export const PopupIconDownload = styled.div`
  display: flex;
  margin-top: 20px; 
`

export const PopupText = styled.div`
  display: flex;
`

export const PopupLink = styled.a`

`

export const PopupCloseWrapper = styled.div`
  display: flex;
  justify-content: flex-end;
`

export const PopupClose = styled.span`
  color: #aaa;
  float: right;
  font-size: 28px;
  font-weight: bold;

  &:hover{
    color: black;
    text-decoration: none;
    cursor: pointer;
  }
`