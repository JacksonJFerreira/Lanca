import React, { useState } from 'react';
import * as S from "./styled"
import { Download } from "@styled-icons/boxicons-solid/Download";

import Title from "../../Title";
import Line from "../../Line";

const PopupInformativo = (props) => {
  //const [openModal, setOpenModal] = useState(false);

  const CloseModal = async () => {
    props.setOpenModal(false);
  }

  window.onclick = function (event) {
    if (event.target.id == 'modal') {
      CloseModal();
    }
  }

  return (
    <>
      <S.PopupWrapper id="modal" visible={props.visible}>
        <S.PopupContent>
          <S.PopupCloseWrapper>
            <S.PopupClose onClick={() => CloseModal()}>&times;</S.PopupClose>
          </S.PopupCloseWrapper>
          <S.PopupHeader>
            <Title
              corFonte="azul"
              corDetalhe="amarelo"
              texto="Nova versão do Lança IDF disponível"
            />
            <Line />
          </S.PopupHeader>

          <S.PopupText>
            Notamos que você não está utilizando a versão mais atualizada do Lança IDF!
            <br />
            Para utilizar a última versão, favor clicar no link abaixo e realizar o download.
          </S.PopupText>
          <S.PopupIconDownload>
          </S.PopupIconDownload>
        </S.PopupContent>
      </S.PopupWrapper>
    </>
  );
}

export default PopupInformativo;