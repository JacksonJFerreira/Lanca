import React from "react";
import PropTypes from "prop-types";

import "./styles.css";

// tipoFonte pode ser vazio ou negritofraco, esse negrito fráco está sendo
// utilizado no header, por exeplo.
const Title = ({ corFonte, corDetalhe, texto, size, center, tipoFonte }) => {
  return (
    <div
      className={`title-wrapper ${center == true ? "center" : "left"} ${
        texto == "" ? "invisible" : "visible"
        }`}
    >
      <div
        style={{ fontSize: size }}
        className={`title${
          tipoFonte == "negritomedio" ? "-negritomedio" : ""
          } title-${corFonte}`}
      >
        {texto}
      </div>
      <div className={`detail-${corDetalhe}`}></div>
    </div>
  );
};

Title.propTypes = {
  corFonte: PropTypes.oneOf(["azul", "verde", "branco"]),
  corDetalhe: PropTypes.oneOf(["amarelo", "azulclaro", "verde", "none"]),
  texto: PropTypes.string,
};

export default Title;
