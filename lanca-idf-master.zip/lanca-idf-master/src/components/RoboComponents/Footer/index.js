import React from 'react';
import * as S from "./styled"
import logo from "../../images/petrobras.png"

const Footer = () => {
  return (
    <>
      <S.FooterWrapper>
        <S.FooterDisplay>
          <S.FooterGroup>
            <S.FooterText>Desenvolvido por Inovação PGDO/PMF</S.FooterText>
          </S.FooterGroup>
          <S.FooterGroup>
            <S.FooterLogoPetrobras src={logo}></S.FooterLogoPetrobras>
          </S.FooterGroup>
        </S.FooterDisplay>
      </S.FooterWrapper>
    </>
  );
}

export default Footer;