import styled from 'styled-components';

export const FooterWrapper = styled.div`
  display: flex;
  height: 2.5rem;
  color: #006298;
  width: 100%;
`

export const FooterDisplay = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  height: 100%;
  width: 100%;
`
export const FooterText = styled.div`

`

export const FooterLogoPetrobras = styled.img`

`


export const FooterEmail = styled.a`

`

export const FooterGroup = styled.div`
  margin: auto 20px 5px 20px;
`
