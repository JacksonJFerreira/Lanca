import React from "react"
import GlobalStyle from "../../styles/global"
import TopBar from "../TopBar";
import Footer from "../Footer";
import Menu from "../Menu";


import * as S from "./styled"

const Layout = ({ children }) => {
  return (
    <S.LayoutWrapper>
      <TopBar />
      <S.LayoutContent>
        <Menu />
        <S.Content>
          {children}
          <Footer />
        </S.Content>
      </S.LayoutContent>

      <GlobalStyle />
    </S.LayoutWrapper>
  )
}

export default Layout;