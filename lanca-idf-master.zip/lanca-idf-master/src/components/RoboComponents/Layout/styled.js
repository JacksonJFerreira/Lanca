import styled from 'styled-components';


export const LayoutWrapper = styled.div`
  height: 80vh;
`
export const Content = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
`
export const LayoutContent = styled.div`
  display: flex;
  flex-direction: row;
`