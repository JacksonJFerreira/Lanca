import styled from 'styled-components';
import { Button } from "react-bootstrap";

export const ButtonWrapper = styled.div`
  display: flex;
  flex-direction: row;
`

export const ButtonRun = styled(Button)`

  &:hover{
    cursor: pointer;
  }

  &:disabled{
    cursor: default;
  }
`



export const ButtonTitle = styled.div`
  font-family: "Trebuchet MS";
  color: #006298;
  font-style: normal;
  font-weight: bold;
  padding-top: 3px;
  font-size: 18px;
  line-height: 24px;
`
