import React from 'react';
import * as S from "./styled"


const Button = ({ action, content, disabled }) => {
  return (
    <S.ButtonWrapper>
      <S.ButtonRun onClick={action} disabled={disabled}>{content}</S.ButtonRun>
    </S.ButtonWrapper>
  );
}

export default Button;