import React from 'react';
import * as S from "./styled"

const LoadScreen = () => {

  return (
    <>
      <S.LoadScreenWrapper>
        <S.LoadScreenText>
          {"Carregando Lança IDF ..."}
        </S.LoadScreenText>
        <S.LoadScreenFooter>
          <S.LoadScreenFooterText>{"Desenvolvido por Inovação PGDO/PMF"}</S.LoadScreenFooterText>
          <S.LoadScreenFooterLogoPetrobras></S.LoadScreenFooterLogoPetrobras>
        </S.LoadScreenFooter>
      </S.LoadScreenWrapper>
    </>
  );
}

export default LoadScreen;