import styled from 'styled-components';

export const LoadScreenWrapper = styled.div`
  display: flex;
  flex-direction: column;
  background: linear-gradient(128.23deg, rgba(255, 255, 255, 0) -16.94%, #026DA8 53.39%, #003D5F 116.77%), #006298;
  color: #fff;
  height: 100vh;
`

export const LoadScreenText = styled.div`
  margin: auto;
  background-color: none;
  font-family: "Trebuchet MS";
`

export const LoadScreenFooter = styled.div`
  background-color: none;
  display: flex;
  flex-direction: row;
  margin: auto 20px 5px 20px;
`

export const LoadScreenFooterText = styled.div`
background-color: none;
  font-size: 10px;
  font-family: "Trebuchet MS";
`

export const LoadScreenFooterLogoPetrobras = styled.div`
`

