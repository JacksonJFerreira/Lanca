import styled from "styled-components";

export const TopBarWrapper = styled.div`
  display: flex;
  background: #006298;
  height: 30px;

  flex-direction: row;
  justify-content: space-between;

  -webkit-user-select: none;
  -webkit-app-region: drag;
`;

export const TopBarGroup = styled.div`
  background: #006298;
`;

export const TopBarIcon = styled.div``;

export const TopBarText = styled.div`
  background: #006298;
  padding-top: 5px;
  color: #fff;
`;

export const TopBarControl = styled.div`
  -webkit-app-region: no-drag;
  display: flex;
  flex-direction: row;
`;

export const ControlButton = styled.button`
  height: 30px;
  width: 30px;
  background-color: #006298;
  color: #fff;
  border: none;

  &:hover {
    background-color: #198ECE;
    cursor: pointer;

    svg {
      background: #198ECE;
      cursor: pointer;
    }
  }

  svg {
    height: 20px;
    width: 20px;
    background: #006298;
  }
`;
