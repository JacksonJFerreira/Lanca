import React from "react";
import * as S from "./styled";

import { Minimize } from "@styled-icons/material-rounded/Minimize";
import { CropSquare } from "@styled-icons/material-rounded/CropSquare";
import { Close } from "@styled-icons/material-rounded/Close";

import ipc from "../../../services/icp";

const TopBar = () => {
  const closeButton = () => {
    console.log("closeButton");
    ipc.send("close-main");
  };

  const closeMinimize = () => {
    console.log("closeMinimize");
    ipc.send("minimize-main");
  };

  const closeMaxmize = () => {
    console.log("closeMaxmize");
    ipc.send("maxmize-main");
  };

  return (
    <>
      <S.TopBarWrapper>
        <S.TopBarGroup>
          <S.TopBarIcon></S.TopBarIcon>
        </S.TopBarGroup>

        <S.TopBarGroup>
          <S.TopBarText>Lança IDF</S.TopBarText>
        </S.TopBarGroup>

        <S.TopBarGroup>
          <S.TopBarControl>
            <S.ControlButton onClick={closeMinimize}>
              <Minimize />
            </S.ControlButton>
            <S.ControlButton onClick={closeMaxmize}>
              <CropSquare />
            </S.ControlButton>
            <S.ControlButton onClick={closeButton}>
              <Close />
            </S.ControlButton>
          </S.TopBarControl>
        </S.TopBarGroup>
      </S.TopBarWrapper>
    </>
  );
};

export default TopBar;
