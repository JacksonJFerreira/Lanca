import React from "react";
import PropTypes from "prop-types";
import HeaderNav from "../HeaderNav";
import Footer from "../Footer";
import TopBar from "../RoboComponents/TopBar";


import "./styles.css";

const Layout = ({ children }) => {


  function topFrameWindow() {
    return (navigator.userAgent.toLowerCase().indexOf(' electron/') > -1 ?
      <><TopBar /></> : "")
  }

  return (
    <>
      {topFrameWindow()}
      <div className={navigator.userAgent.toLowerCase().indexOf(' electron/') > -1 ?
        "false-body" : ""}>
        <HeaderNav />
          <div className="page-loader">
            {children}
            <Footer />
          </div>
      </div>
    </>
  );
};

Layout.propTypes = {
  children: PropTypes.node.isRequired,
};

export default Layout;
