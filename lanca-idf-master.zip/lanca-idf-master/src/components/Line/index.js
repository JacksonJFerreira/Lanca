import React from "react";

import "./styles.css";

const Line = () => {
  return <div className="line"></div>;
};

export default Line;
