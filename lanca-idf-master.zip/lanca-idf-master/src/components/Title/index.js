import React from "react";
import PropTypes from "prop-types";

import "./styles.css";

// tipoFonte pode ser vazio ou negritofraco, esse negrito fráco está sendo
// utilizado no header, por exeplo.
const Title = ({ corFonte, corDetalhe, texto, size, center, tipoFonte, lineHeight }) => {
  return (
    <div
      className={`title-wrapper ${center == true ? "center" : "left"} ${
        texto == "" ? "invisible" : "visible"
        }`}
    >
      <div
        style={{ fontSize: size, lineHeight: (lineHeight ? lineHeight : "1.5") }}
        className={`title${
          tipoFonte == "negritomedio" ? "-negritomedio" : (tipoFonte == "semnegrito" ? "-semnegrito" : "")
          } title-${corFonte}`}
      >
        {texto}
      </div>
      <div style={{ display: (corDetalhe == "none" ? "none" : "block") }} className={`detail-${corDetalhe}`}></div>
    </div>
  );
};

Title.propTypes = {
  corFonte: PropTypes.oneOf(["azul", "verde", "branco", "azulclaro"]),
  corDetalhe: PropTypes.oneOf(["amarelo", "azulclaro", "verde", "none"]),
  texto: PropTypes.string,
};

export default Title;
