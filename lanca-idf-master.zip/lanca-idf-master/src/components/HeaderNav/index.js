import "./styles.css";
import React from "react";
import { Container } from "react-bootstrap";
import Title from "../Title";


const HeaderNav = () => {

  return (
    <>
      <Container className="wrapper-header">
        <div className="wrapper-header-group">
          <a href="/">
            <Title
              corDetalhe="amarelo"
              corFonte="branco"
              texto="Portal SSUB"
              size="1.6rem"
              tipoFonte="negritomedio"
            />
          </a>
        </div>
        <div className="wrapper-header-group" id="myMenu">
        </div>
      </Container>
    </>
  );
};

export default HeaderNav;
