const usuario = {
  name: "",
  sapId: "",
  shortName: "",
  login: "",
  department: {
    acronym: ""
  }
};

export default usuario;
