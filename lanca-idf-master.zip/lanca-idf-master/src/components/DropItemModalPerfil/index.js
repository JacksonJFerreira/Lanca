import React, { useState, useEffect } from "react";
import {
  Dropdown,
  Modal,
  Form,
  Row,
  Col,
  Button,
  Alert,
} from "react-bootstrap";
import BootstrapTable from "react-bootstrap-table-next";
import paginationFactory from "react-bootstrap-table2-paginator";
import ToolkitProvider, { Search } from "react-bootstrap-table2-toolkit";

import Title from "../Title";

import colunas from "./configuracaoTable";
import variaveisPerfil from "./variaveisPerfil";

const DropItemModalPerfil = ({ user }) => {
  const { SearchBar } = Search;
  // states funcionais
  const [show, setShow] = useState(false);

  const respostaInicial = {
    mensagem: "",
    feedback: "",
    show: false,
  };

  // states de objetos
  const [usuario, setUsuario] = useState(user);
  const [perfisUsuario, setPerfisUsuario] = useState([]);
  const [papeis, setPapeis] = useState([]);
  const [perfil, setPerfil] = useState(variaveisPerfil);
  const [papel, setPapel] = useState({ nome: "", atividade: "" });

  const [resposta, setResposta] = useState(respostaInicial);

  const handleClose = () => setShow(false);
  const handleShow = () => {
    setShow(true);
    clearResposta();
  };

  useEffect(() => {
    loadPerfis();
    loadPerfisUsuario();
  }, []);

  const clearResposta = () => {
    setResposta({ ...respostaInicial });
  };

  async function handleSalvar(event) {
    event.preventDefault();

    try {
      // const response = await apinetframework.post("/portalapi/perfil/store", perfil);
      // console.log(response.data);
      // setResposta(response.data);
    } catch (e) {
      console.log(e);
    }
    loadPerfisUsuario();
  }

  async function loadPerfisUsuario() {

  }

  async function loadPerfis() {

  }

  function selecionarAtividade(papelSelecionado) {
    setPapel({ ...papel, nome: papelSelecionado });
    papeis.map((p) => {
      if (p.nome == papelSelecionado) {
        setPapel({ nome: p.nome, atividade: p.atividade });
        setPerfil({ ...perfil, fkPapel: p.id });
      }
    });
  }

  return (
    <>
      <Dropdown.Item onClick={handleShow}>Perfís de Acesso</Dropdown.Item>

      <Modal show={show} dialogClassName="modal-lg" onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>
            <Title
              corDetalhe="amarelo"
              corFonte="verde"
              texto="Gestão de Perfil de Usuário"
            />
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Alert
            show={resposta.show}
            variant={resposta.feedback == "sucesso" ? "success" : "danger"}
          >
            {resposta.mensagem}
          </Alert>
          <Form onSubmit={handleSalvar}>
            <Row>
              <Form.Group as={Col} sm={9}>
                <Form.Label>Nome do Perfil</Form.Label>
                <Form.Control
                  type="text"
                  as="select"
                  required
                  value={papel.nome}
                  onChange={(event) => {
                    selecionarAtividade(event.target.value);
                  }}
                >
                  <option></option>
                  {papeis.map((papel) => (
                    <option key={papel.id}>{papel.nome}</option>
                  ))}
                </Form.Control>
              </Form.Group>

              <Form.Group as={Col} sm={2}>
                <Form.Label>Usuário</Form.Label>
                <Form.Control
                  type="text"
                  disabled
                  value={usuario.login.toUpperCase()}
                ></Form.Control>
              </Form.Group>
            </Row>
            <Row>
              <Col>
                <Form.Group>
                  <Form.Label>Atividade do Perfil</Form.Label>
                  <Form.Control
                    type="text"
                    as="textarea"
                    disabled
                    value={papel.atividade}
                  />
                </Form.Group>
              </Col>
            </Row>

            <Row>
              <Col>
                <Form.Group>
                  <Form.Label>Justificativa</Form.Label>
                  <Form.Control
                    type="text"
                    as="textarea"
                    maxlength={255}
                    minlength={10}
                    required
                    value={perfil.justificativaUsuario}
                    onChange={(event) => {
                      setPerfil({
                        ...perfil,
                        justificativaUsuario: event.target.value,
                        status: "Solicitado",
                      });
                    }}
                  />
                </Form.Group>
              </Col>
            </Row>
            <Row>
              <Col>
                <Button variant="secondary" onClick={handleClose}>
                  Cancelar
                </Button>{" "}
                <Button variant="primary" type="submit">
                  Salvar
                </Button>
              </Col>
            </Row>
          </Form>

          <Col className="mt-5 p-0">
            <ToolkitProvider
              keyField="id"
              data={perfisUsuario}
              columns={colunas}
              search
            >
              {(props) => (
                <>
                  <Row>
                    <Col sm="3">
                      <SearchBar
                        {...props.searchProps}
                        placeholder={"Pesquisar"}
                      />
                    </Col>
                  </Row>
                  <BootstrapTable
                    {...props.baseProps}
                    pagination={paginationFactory({ sizePerPage: 5 })}
                  />
                </>
              )}
            </ToolkitProvider>
          </Col>
        </Modal.Body>
        <Modal.Footer></Modal.Footer>
      </Modal>
    </>
  );
};

export default DropItemModalPerfil;
