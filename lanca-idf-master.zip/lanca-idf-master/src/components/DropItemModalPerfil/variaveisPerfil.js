const variaveisPerfil = {
  id: null,
  status: "",
  fkPapel: null,
  observacaoGestor: "",
  atividade: "",
  justificativaUsuario: "",
};

export default variaveisPerfil;
