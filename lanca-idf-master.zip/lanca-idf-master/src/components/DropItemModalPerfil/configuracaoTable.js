import React from "react";

const colunas = [
  {
    dataField: "Papel.nome",
    text: "Nome Perfil",
    sort: true,
    formatter: (cell) => {
      return (
        <>
          <text style={{ fontSize: "14px" }}>{cell}</text>
        </>
      );
    },
    headerStyle: () => {
      return {
        width: "20%",
        padding: "5px",
        textAlign: "center",
        fontSize: "12px",
      };
    },
  },
  {
    dataField: "status",
    text: "Status",
    sort: true,
    formatter: (cell) => {
      return (
        <>
          <text style={{ fontSize: "14px" }}>{cell}</text>
        </>
      );
    },
    headerStyle: () => {
      return {
        width: "15%",
        padding: "5px",
        textAlign: "center",
        fontSize: "12px",
      };
    },
  },
  {
    dataField: "justificativaUsuario",
    text: "Justificativa",
    sort: true,
    formatter: (cell) => {
      return (
        <>
          <text style={{ fontSize: "14px" }}>{cell}</text>
        </>
      );
    },
    headerStyle: () => {
      return {
        width: "45%",
        padding: "5px",
        textAlign: "center",
        fontSize: "12px",
      };
    },
  },
  {
    dataField: "observacaoGestor",
    text: "Observação Gestor",
    sort: true,
    formatter: (cell) => {
      return (
        <>
          <text style={{ fontSize: "14px" }}>{cell}</text>
        </>
      );
    },
    headerStyle: () => {
      return {
        width: "30%",
        padding: "5px",
        textAlign: "center",
        fontSize: "12px",
      };
    },
  },
];

export default colunas;
