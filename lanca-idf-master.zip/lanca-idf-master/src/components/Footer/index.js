import React from "react";
import "./styles.css";
import { Container } from "react-bootstrap";
import logo_petrobras from "../../images/logo_petrobras.png";

import { EmailOutline } from "@styled-icons/evaicons-outline/EmailOutline";
import { UserTie } from "@styled-icons/fa-solid/UserTie";
import { Web } from "@styled-icons/material/Web";

const NavFooter = () => {
  return (
    <>
      <Container className="container-footer">
        <div className="wrapper-footer">
          <div className="div-footer">
            <div>
              <UserTie className="icon-footer" />
              <p>Gestão: SSUB/PGDO/PMF</p>
            </div>
            <div>
              <EmailOutline className="icon-footer" />
              <p>
                {"Chave Estrutural: "}
                <a href="mailto:inov@petrobras.com.br">INOV</a>
              </p>
            </div>
            <div>
              <Web className="icon-footer" />
              <p>Portal SSUB</p>
            </div>
          </div>
          <div>
            <img src={logo_petrobras} alt="logo Petrobras" />
          </div>
        </div>
      </Container>
    </>
  );
};

export default NavFooter;
