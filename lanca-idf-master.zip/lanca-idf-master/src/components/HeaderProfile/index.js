import React, { useState, useEffect } from "react";
import { Dropdown, Image } from "react-bootstrap";
import DropItemModalUsuario from "../DropItemModalUsuario";
import DropItemModalPerfil from "../DropItemModalPerfil";
import Title from "../Title";
import Line from "../Line";
import user from "../../images/user.png";
import axios from "axios";

import "./styles.css";

const HeaderProfile = ({ usuario }) => {
  const [reverencia, setReverencia] = useState();
  const [indexApiImagem, setIndexApiImagem] = useState(0);

  useEffect(() => {
    definirPeriodo();
  }, []);



  function definirPeriodo() {
    var hoje = new Date();
    var agora = hoje.getHours();

    if (agora >= 12 && agora < 18) {
      setReverencia("Boa tarde");
    } else if (agora >= 6 && agora < 12) {
      setReverencia("Bom dia");
    } else {
      setReverencia("Boa noite");
    }
  }


  function handleLogout() {
    localStorage.removeItem("@portal_opsub");
  }

  function addNextImage(ev) {
    setIndexApiImagem(indexApiImagem + 1);
    switch (indexApiImagem) {
      case 0:
        ev.target.src = `http://apl.ti.petrobras.com.br/fotos/0${usuario.sapId}.jpg`;
        break;
      case 1:
        ev.target.src = `http://apl.ti.petrobras.com.br/fotos/${usuario.sapId}.jpg`;
        break;
      case 2:
        ev.target.src = `https://sispat.petrobras.com.br/api/fotos/0${usuario.sapId}.jpg`;
        break;
      case 3:
        ev.target.src = `https://sispat.petrobras.com.br/api/fotos/${usuario.sapId}.jpg`;
        break;
    }
  }


  return (<></>);
    // <Dropdown alignRight>
    //   <Dropdown.Toggle className="foto-header">
    //     {(usuario.sapId == "" ? "" :
    //       <Image
    //         onError={addNextImage}
    //         src={
    //           `http://apl.ti.petrobras.com.br/fotos/0${usuario.sapId}.jpg`
    //         }
    //         alt="Avatar"
    //         className="avatar"
    //       ></Image>
    //     )}
    //   </Dropdown.Toggle>
    //   <Dropdown.Menu>
    //     <div className="avatar-center-wrapper">
    //       <img
    //         onError={addNextImage}
    //         src={
    //           `http://apl.ti.petrobras.com.br/fotos/0${usuario.sapId}.jpg`
    //         }
    //         alt="Avatar"
    //         className="avatar-center"
    //       ></img>
    //     </div>
    //     <Title
    //       texto={`Olá${usuario.shortName != null ? ", " + reverencia + "!" : ""}`}
    //       center={true}
    //       corFonte={"verde"}
    //       size={"18px"}
    //       tipoFonte={"negritomedio"}
    //     />
    //     <Title
    //       texto={`${usuario.shortName != null ? usuario.shortName : ""}`}
    //       center={true}
    //       corFonte={"verde"}
    //       size={"18px"}
    //     />
    //     <Line />
    //     <DropItemModalUsuario user={usuario} />
    //     <Dropdown.Divider />
    //     <Dropdown.Item href="/login" onClick={handleLogout}>
    //       Sair
    //     </Dropdown.Item>
    //   </Dropdown.Menu>
    // </Dropdown>
  
};

export default HeaderProfile;
