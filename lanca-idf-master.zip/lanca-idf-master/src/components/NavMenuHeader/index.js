import React from "react";
import { Dropdown } from "react-bootstrap";
import { Menu } from "@styled-icons/entypo/Menu";

import "./styles.css";
import links from "../../utils/links";

const NavMenuHeader = (props) => {
  return (
    <div className={`wrapper-nav-menu ${props.className}`}>
      <Dropdown className="nav-menu-dropdown">
        <Dropdown.Toggle className="nav-menu-icon">
          <Menu />
        </Dropdown.Toggle>
        <Dropdown.Menu>
          <span className="title-bar-menu"> Links Externos </span>
          {links.map((link, i) => (
            <Dropdown.Item key={i} href={link.url} target="_blank">
              {link.label}
            </Dropdown.Item>
          ))}
        </Dropdown.Menu>
      </Dropdown>
    </div>
  );
};

export default NavMenuHeader;
