import React, { useState } from "react";
import {
  Dropdown,
  Modal,
  Form,
  Row,
  Col,
} from "react-bootstrap";
import Title from "../Title";

const DropItemModalUsuario = ({ user }) => {
  const [show, setShow] = useState(false);
  const [usuario, setUsuario] = useState(user);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  return (
    <>
      <Dropdown.Item onClick={handleShow}>Dados de Usuário</Dropdown.Item>

      <Modal show={show} dialogClassName="modal-90w" onHide={handleClose}>
        <Form >
          <Modal.Header closeButton>
            <Modal.Title>
              <Title
                corDetalhe="amarelo"
                corFonte="verde"
                texto="Dados de Usuário"
              />
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Form.Group>
              <Form.Label>Nome Completo</Form.Label>
              <Form.Control
                type="text"
                disabled
                value={usuario.name}
                onChange={(event) => {
                  setUsuario({ ...usuario, name: event.target.value });
                }}
              />
            </Form.Group>

            <Row>
              <Col>
                <Form.Group>
                  <Form.Label>Identificador</Form.Label>
                  <Form.Control
                    type="text"
                    disabled
                    value={usuario.sapId}
                    onChange={(event) => {
                      setUsuario({
                        ...usuario,
                        sapId: event.target.value,
                      });
                    }}
                  />
                </Form.Group>
              </Col>
            </Row>

            <Form.Group>
              <Form.Label>Gerência</Form.Label>
              <Form.Control
                type="text"
                disabled
                value={usuario.department.acronym}
                onChange={(event) => {
                  setUsuario({
                    ...usuario,
                    department: { acronym: event.target.value },
                  });
                }}
              />
            </Form.Group>
          </Modal.Body>
        </Form>
      </Modal>
    </>
  );
};

export default DropItemModalUsuario;
