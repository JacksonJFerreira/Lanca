const {
  app,
  BrowserWindow,
  ipcMain,
  Tray,
} = require("electron");

const path = require("path");
const url = require('url');
//const debug = require('electron-debug');  //--> função utilizada somente para debugar a interface do programa. Ctrl + Shift + i para exibir a tela de inspecionar no programa. Lembrando que tem que descomentar a função debug caso queira utilizar esse recurso
const isDev = require("electron-is-dev");
const flagVersao = require("./versao.js");

const ListenerCreator = require("./listenerCreator.js");

let mainWindow;
let loadingScreen;

app.disableHardwareAcceleration();

exports.execProcess = (process, callback) => {
  const { exec } = require("child_process");
  const callExec = exec(process);

  callExec.stdout.on("data", function (data) {
    callback(data);
  });
  callExec.stderr.on("data", function (data) {
    callback("<b>ERROR:</b> \n" + data);
  });
};

const createLoadingScreen = () => {
  /// create a browser window
  loadingScreen = new BrowserWindow(
    Object.assign({
      /// set the window height / width
      width: 400,
      height: 400,
      /// remove the window frame, so it will rendered without frames
      frame: false,
      /// and set the transparency to true, to remove any kind of background
      transparent: true,
      webPreferences: {
        nodeIntegration: true,
        webSecurity: true,
      },
    })
  );
  tray = new Tray(__dirname + "/../src/images/icon-tray.png");

  tray.setToolTip("SAP Script Web");

  loadingScreen.setResizable(false);

  const startLoagindUrl = isDev
    ? "http://localhost:3000/#/loading"
    : `file://${path.join(__dirname, "/../loading.html")}`;

  loadingScreen.loadURL(startLoagindUrl);
  loadingScreen.on("closed", () => (loadingScreen = null));

  loadingScreen.webContents.on("did-finish-load", () => {
    loadingScreen.show();
  });
};

const createWindow = async () => {
  const listener = await ListenerCreator(ipcMain);
  listener.initCreation();

  mainWindow = new BrowserWindow({
    width: 1300,
    height: 900,
    frame: false,
    show: false,
    // Caracteristicas visuais da janela
    // autoHideMenuBar: true,
    // titleBarStyle: 'customButtonsOnHover',
    useContentSize: false, // Inibe mostragem de dimensao da janela

    webPreferences: {
      nodeIntegration: true,
      nodeIntegrationInWorker: true,
      webSecurity: true,
    },
  });

  //Teste
 // let startUrl = "http://localhost:3000/robo/main";
  // //Produção
  // let startUrl = "http://portalssub.petrobras.biz/robo/main";

  let startUrl = isDev 
      ? "http://localhost:3000/#/"
      : `file://${path.join(__dirname, "/../index.html")}`;

  mainWindow.loadURL(startUrl);
 
  mainWindow.on("closed", () => {
    mainWindow = null;
  });

  mainWindow.webContents.on("did-finish-load", () => {
    if (loadingScreen) {
      loadingScreen.close();
    }
    mainWindow.show();
  });


  mainWindow.webContents.on("did-fail-load", () => {

    mainWindow = new BrowserWindow({
      width: 1000,
      height: 900,
      frame: true,
      // Caracteristicas visuais da janela
      // autoHideMenuBar: true,
      // titleBarStyle: 'customButtonsOnHover',
      useContentSize: false, // Inibe mostragem de dimensao da janela

      webPreferences: {
        nodeIntegration: true,
        nodeIntegrationInWorker: true,
        webSecurity: true,
      },
    });
    mainWindow.loadFile(`${path.join(__dirname, "/../error.html")}`);
    mainWindow.setMenuBarVisibility(false);

    if (isDev) {
      //debug(); //--> função utilizada somente para debugar a interface do programa. Ctrl + Shift + i para exibir a tela de inspecionar no programa. Lembrando que tem que descomentar a importação da biblioteca do debug caso queira utilizar esse recurso
      mainWindow.webContents.openDevTools();
    }
  });

  ipcMain.on("runShowVersao", async (event) => {
    event.sender.send('responseVersao', flagVersao);
  });

  ipcMain.on("close", (event, data) => {
    document
      .getElementById("log")
      .insertAdjacentHTML("beforeend", data + "<br>");
  });
};

app.on("ready", () => {
  createLoadingScreen();
  setTimeout(() => {
    createWindow();
  }, 8000);
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    app.quit();
  }
});

app.on("activate", () => {
  if (mainWindow === null) {
    createWindow();
  }
});

ipcMain.on("close-main", () => {
  mainWindow.close();
});

ipcMain.on("minimize-main", () => {
  mainWindow.minimize();
});

ipcMain.on("maxmize-main", () => {
  mainWindow.isMaximized() ? mainWindow.unmaximize() : mainWindow.maximize();
});
