const FactoryRequestIDF = require("../src/ScriptIDF/factory.js");

async function ListenerCreator(ipcMain) {

  const initCreation = async function () {
    //Listeners do RPA IDF
    const factory = await FactoryRequestIDF();
    ipcMain.on("readIDF", factory.readerScriptIDF);
    ipcMain.on("runScriptIDFFiscal", factory.actFiscalScriptIDF);
    ipcMain.on("runScriptIDFGerente", factory.actGerenteScriptIDF);
  }

  return { initCreation };
}

module.exports = ListenerCreator;